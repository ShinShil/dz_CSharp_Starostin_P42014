﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    [Serializable]
    class Player
    {
        static private int playerExemplyar = 0;
        private List<Card> hand;
        private int handSumm;
        private string name;
        private ShowStates state;
        private GameStates gameState;
        public ShowStates State
        {
            get { return state; }
            set { state = value; }
        }
        public GameStates GameState
        {
            get { return gameState; }
            set { gameState = value; }
        }
        public string Name
        {
            get { return name; }
            set
            {
                if (this.gameState == GameStates.WaitingForGame)
                    name = value;
            }
        }
        public enum GameStates
        {
            Playing = 0,
            GoAway = 1,
            BlackJack = 2,
            TwentyOne = 3,
            WaitingForGame = 4,
            Lose = 5
        }

        public enum ShowStates
        {
            Waiting = 0,
            Active = 1,
            Lose = 2,
            Win = 3,
            EndGame = 4
        }

        public int Summ {
            get { return handSumm; }
        }

        public Player()
        {
            hand = new List<Card>();
            name = String.Format("Player " + (playerExemplyar + 1));
            ++playerExemplyar;
            state = ShowStates.Waiting;
        }
        ~Player()
        {
            --playerExemplyar;
        }
        
        public void Show()
        {
            switch (state)
            {
                case ShowStates.Waiting:
                    ShowWait();
                    break;
                case ShowStates.Active:
                    ShowActive();
                    break;
                case ShowStates.EndGame:
                    ShowEndGame();
                    break;
            }
        }

        private void ShowWait()
        {
            Console.Write("{0}: ", name);
            for (int i = 0; i < hand.Count; ++i)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
        public void TakeCard(Card card)
        {
            hand.Add(card);
            if (card.Cost == 100)
            {
                handSumm = 21;
                GameState = GameStates.TwentyOne;
                return;
            }
            handSumm += card.Cost;
            if (handSumm > 21)
            {
                if (card.Cost == 11)
                {
                    handSumm -= 10;
                }
                else
                {
                    GameState = GameStates.Lose;
                }
            }
            if(handSumm == 21 && hand.Count == 2 )
            {
                GameState = GameStates.BlackJack;
            }
            if(handSumm == 21 && hand.Count != 2)
            {
                GameState = GameStates.TwentyOne;
            }
            if (handSumm == 21)
            {
                GameState = GameStates.TwentyOne;
            }
        }
        private void ShowActive()
        {
            Console.WriteLine("Turn of the player: " + name);
            Console.Write("\tCurrent hand: ");
            for (int i = 0; i < hand.Count; ++i)
            {
                hand[i].Show();
                if (i + 1 != hand.Count)
                    Console.Write(", ");
            }
            Console.WriteLine("\n\tThe summ of the hand: " + handSumm);
        }

        private void ShowEndGame()
        {
            Console.WriteLine("Player: " + name);
            Console.Write("\tEnd hand: ");
            for (int i = 0; i < hand.Count; ++i)
            {
                hand[i].Show();
                if (i + 1 != hand.Count)
                    Console.Write(", ");
            }
            Console.WriteLine("\n\tThe summ of the hand: " + handSumm);
        }
    }
}
