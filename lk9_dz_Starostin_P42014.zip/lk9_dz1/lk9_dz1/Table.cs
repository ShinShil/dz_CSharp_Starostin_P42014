﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    [Serializable]
    class Table
    {
        #region SwitchTables
        public delegate bool KeyPress(ConsoleKeyInfo info);
        static public event KeyPress KeyPressed;
        static public ConsoleKeyInfo ReadKeyEvent()
        {
            ConsoleKeyInfo res;
            res = Console.ReadKey();
            if (res.Modifiers == ConsoleModifiers.Shift)
                KeyPressed(res);
            return res;
        }
        #endregion
        #region FieldsEnumsProperties
        #region Fields
        private States GameState; //Show, End the game, defines the dialog, that should be shown
        private int activePlayer;
        private List<Player> players;
        private string gameName;
        List<Deck> decks;
        #endregion
        #region enums
        public enum States
        {
            Begin = 0,
            Go = 1,
            End = 2,
            Help = 3
        }
        #endregion
        #region properties
        public string GameName
        {
            get
            {
                return gameName;
            }
        }
        #endregion
        #endregion
        #region construnctors
        public Table()
        {
            players = new List<Player>();
            GameState = States.Begin;
            gameName = "Игра 21 очко";
            for (int i = 0; i < 4; ++i)
            {
                players.Add(new Player());
            }
            decks = new List<Deck>();
            for (int i = 0; i < 1; ++i)
            {
                decks.Add(new Deck((int)Deck.DeckSize.FiftyFour));
                decks[i].Init();
            }
            players[0].State = Player.ShowStates.Active;
            activePlayer = 0;
        }
        public States gameState
        {
            get { return GameState; }
            set { GameState = value; }
        }
        #endregion
        public void Show(int currTable = 0)
        {
            Console.WriteLine("\n\tСтол {0} - \"{1}\"", currTable + 1, this.GameName);
            switch (GameState)
            {
                case States.Begin:
                    StartDialog(currTable);
                    break;
                case States.Go:
                    GoDialog();
                    break;
                case States.End:
                    EndDialog();
                    break;
                case States.Help:
                    HelpDialog();
                    break;
            }
        }
        private void GiveCard(Player player)
        {
            Random rnd = new Random();
            int index = rnd.Next(decks[0].MaxLeftCard);
            Card tmp = decks[0].GetCard(index);
            decks[0].RemoveCard(index);
            player.TakeCard(tmp);
        }
        private void Init()
        {
            for (int i = 0; i < players.Count; ++i)
            {
                for (int j = 0; j < 2; ++j)
                {
                    GiveCard(players[i]);
                }
            }
        }
        private void StartDialog(int currTable)
        {
            Menu21 startMenu = new Menu21();
            startMenu.AddRecord("1.Start the game", delegate ()
            {
                GameState = States.Go;
                Init();
                startMenu.EndDlg();
            });
            startMenu.AddRecord("2.Game settings", delegate ()
            {
                GameState = States.Go;
                startMenu.EndDlg();
            });
            startMenu.AddRecord("3.Help", delegate ()
            {
                GameState = States.Help;
                startMenu.EndDlg();
            });
            startMenu.AddRecord("4.Players settings", delegate ()
            {
                GameState = States.Go;
                startMenu.EndDlg();
            });
            startMenu.SetHeader(String.Format("\n\tСтол {0} - \"{1}\"", currTable + 1, this.GameName));
            startMenu.StartDlg();
        }
        private void GoDialog()
        {
            Console.Clear();
            PrintCurrSituation();
            ActionDialog();
        }
        private void PrintCurrSituation()
        {
            Console.WriteLine("\n\tWaiting players:\n");
            
            for (int i = 0; i < players.Count; ++i)
            {
                if (players[i].State == Player.ShowStates.Waiting)
                {
                    players[i].Show();
                }
            }
            Console.WriteLine();
            players[activePlayer].Show();
        }
        private void EndDialog()
        {
            List<int> winners = new List<int>();
            List<int> losers = new List<int>();
            List<int> BlackJack = new List<int>();
            int maxPointsWinner = -1;
            int maxPoints = 0;

            Console.Clear();
            Console.WriteLine("\n\t\tGame results\n");
            for (int i = 0; i < players.Count; ++i)
            {
                players[i].State = Player.ShowStates.EndGame;
                players[i].Show();
                if (players[i].GameState == Player.GameStates.Lose)
                    losers.Add(i);
                else
                {
                    if (players[i].Summ > maxPoints)
                    {
                        maxPoints = players[i].Summ;
                        maxPointsWinner = i;
                    }
                    if (players[i].Summ == 21)
                    {
                        if (players[i].GameState == Player.GameStates.BlackJack)
                            BlackJack.Add(i);
                        winners.Add(i);
                    }
                }
                Console.WriteLine();
            }

            if (winners.Count == 0)
            {
                if (maxPointsWinner != -1)
                {
                    for (int i = 0; i < players.Count; ++i)
                    {
                        if (players[i].Summ == maxPoints)
                        {
                            winners.Add(i);
                        }
                    }
                }
                if (winners.Count != 0)
                {
                    Console.WriteLine("Winners");
                    for (int i = 0; i < winners.Count; ++i)
                    {
                        Console.WriteLine("{0}. {1} with the summ - {2}", winners[i] + 1, players[winners[i]].Name, players[winners[i]].Summ);
                    }
                    PrintLosers(winners);
                }
                else
                {
                    Console.WriteLine("No winners");
                    Console.WriteLine("\nLosers: ");
                    for (int i = 0; i < losers.Count; ++i)
                    {
                        Console.WriteLine((i + 1) + "." + players[losers[i]].Name);
                    }
                }
            }
            else
            {
                Console.WriteLine("Winners");
                if (BlackJack.Count != 0)
                {
                    for (int i = 0; i < BlackJack.Count; ++i)
                    {
                        Console.WriteLine("{0}. {1} - 21 Black Jack", BlackJack[i] + 1, players[BlackJack[i]].Name);
                    }
                    PrintLosers(BlackJack);
                }
                else
                {
                    for (int i = 0; i < winners.Count; ++i)
                    {
                        Console.WriteLine("{0}. {1} - 21", winners[i] + 1, players[winners[i]].Name);
                    }
                    PrintLosers(winners);
                }
            }
            Console.WriteLine("\nPress any key to continue...");
            GameState = States.Begin;
            ReadKeyEvent();
        }
        void PrintLosers(List<int> winners)
        {
            Console.WriteLine("\nLosers");
            for (int i = 0; i < players.Count; ++i)
            {
                if (winners.IndexOf(i) == -1)
                {
                    Console.WriteLine("{0}. {1}; Hand summ - {2}", i + 1, players[i].Name, players[i].Summ);
                }
            }
        }
        private void ActionDialog()
        {
            if (players[activePlayer].GameState == Player.GameStates.Lose)
            {
                Console.WriteLine("\nYou have too much points, you lose, wait while others finish the game");
                Console.WriteLine("Press any key to continue...");
                ReadKeyEvent();
            }
            else
            {
                char ch = 'y';
                while (ch == 'y' && players[activePlayer].GameState != Player.GameStates.Lose)
                {
                    if (players[activePlayer].GameState == Player.GameStates.TwentyOne || players[activePlayer].GameState == Player.GameStates.BlackJack)
                    {
                        Console.WriteLine("\nIt is 21, the goal of the game");
                    }
                    Console.WriteLine("\nWould you like to take one more card? (y)es/n(o)");
                    ch = Table.ReadKeyEvent().KeyChar.ToString().ToLower().ToCharArray()[0];
                    if (ch == 'y')
                    {
                        GiveCard(players[activePlayer]);
                        Console.Clear();
                        PrintCurrSituation();
                    }
                    if (players[activePlayer].GameState == Player.GameStates.Lose)
                    {
                        Console.WriteLine("\nYou have take too much point, you loose");
                        Console.WriteLine("Press any to continue");
                        ReadKeyEvent();
                        break;
                    }
                }
            }
                players[activePlayer].State = Player.ShowStates.Waiting;
                int nextActive = (activePlayer + 1 == players.Count) ? (0) : (activePlayer + 1);
                players[nextActive].State = Player.ShowStates.Active;
                activePlayer = nextActive;
        }

        private void HelpDialog()
        {
            Console.WriteLine("shift + F1, F2, F3, F4, F5, F6, F7, F8, F9, F10: switch between tables form 1 to 10");
            Console.WriteLine("shift + F11: End game and count all results of the game");
            Console.WriteLine("shift + F12: exit");
            Console.WriteLine("Press any to continue...");
            ReadKeyEvent();
            gameState = States.Begin;
        }
        public void StartGame()
        {
            GameState = States.Begin;
        }
    }
}
