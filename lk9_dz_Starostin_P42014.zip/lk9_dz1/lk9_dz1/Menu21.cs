﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    class Menu21:Menu
    {
        public void ChangeTableHandler()
        {
            if(menuDlgState)
                EndDlg();
        }
        public Menu21():base()
        {
            Game.TableChangeEvent += new Game.TableChange(ChangeTableHandler);
        }
        public override int GetChoiceDlg(out string s)
        {
            Console.WriteLine();
            int choice = -1;
            Console.Write("Make a choice: ");
            s = Table.ReadKeyEvent().KeyChar.ToString();
            Int32.TryParse(s, out choice);
            return choice;
        }
    }
}
