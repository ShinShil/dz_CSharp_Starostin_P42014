﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            
            Game game = new Game();
            game.GameStart();
            game.GameGo();
        }
    }
}
