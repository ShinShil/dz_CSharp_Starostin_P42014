﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    [Serializable]
    class Card
    {
        private string picture;
        private int cost;
        private string name;
        public Card()
        {

        }
        public Card(string p, int c)
        {
            picture = p;
            cost = c;
        }
        public void Set(string pic, int c, string name)
        {
            picture = pic;
            cost = c;
            this.name = name;
        }
        public string Picture
        {
            get
            {
                return picture;
            }
        }
        public int Cost
        {
            get
            {
                return cost;
            }
        }

        public void Show()
        {
            if (name == "Joker")
            {
                Console.Write("Joker");
            }
            else {
                Console.Write("{0} {1}", name, picture);
            }
        }
    }
}
