﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk9_dz1
{
    [Serializable]
    class Deck
    {
        private List<Card> cards;
        private int amount;
        public enum DeckSize
        {
            Classic = 36,
            FiftyFour = 54
        }
        public Deck(int amount)
        {
            this.amount = amount;
            cards = new List<Card>(amount);
        }
        public int MaxLeftCard
        {
            get
            {
                return cards.Count;
            }
        }
        public void Show()
        {
            for(int i = 0; i<amount; ++i)
            {

                cards[i].Show();
                Console.WriteLine();
            }
        }
        public Card GetCard(int index)
        {
            return cards[index];
        }
       
        public bool RemoveCard(int index)
        {
            try
            {
                cards.RemoveAt(index);
            }
            catch
            {
                return false;
            }
            return true;
        }
        public void Init()
        {
            if(amount == (int)DeckSize.FiftyFour)
            {
                Init54();
            }
            if(amount == (int)DeckSize.Classic)
            {
                Init36();
            }
        }
        private void Init54()
        {
            cards = null;
            string[] mast = new string[] { "cherva", "bubna", "pika", "trepha" };
            int currMast = 0;
            int currCost = 2;
            string[] names = new string[] { "2", "3", "4", "5", "6","7", "8", "9", "10", "J", "Q", "K", "A" };
            int currName = 0;
            cards = new List<Card>(amount);
            for(int i = 0; i< amount - 2; ++i)
            {
                cards.Add(new Card());
                cards.Last().Set(mast[currMast], currCost, names[currName]);
                if(currName + 1 == names.Length)
                {
                    currName = 0;
                    currMast++;
                    currCost = 2;
                }else
                {
                    ++currName;
                    if(names[currName]!="Q" && names[currName]!="K" && names[currName]!="J")
                    {
                        ++currCost;
                    }
                }
            }
            cards.Add(new Card());
            cards.Last().Set("Joker", 100, "Joker");
            cards.Add(new Card());
            cards.Last().Set("Joker", 100, "Joker");
        }

        private void Init36()
        {
            cards = null;
            string[] mast = new string[] { "cherva", "bubna", "pika", "trepha" };
            int currMast = 0;
            int currCost = 2;
            string[] names = new string[] { "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
            int currName = 0;
            cards = new List<Card>(amount);
            for (int i = 0; i < amount; ++i)
            {
                cards.Add(new Card());
                cards.Last().Set(mast[currMast], currCost, names[currName]);
                if (currName + 1 == names.Length)
                {
                    currName = 0;
                    currMast++;
                    currCost = 2;
                }
                else
                {
                    ++currName;
                    if (names[currName] != "Q" && names[currName] != "K" && names[currName] != "J")
                    {
                        ++currCost;
                    }
                }
            }
        }

    }
}
