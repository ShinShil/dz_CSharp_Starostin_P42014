﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lk9_dz1
{
    public delegate void ChangeStr(object sender, string str);
    public delegate void MenuAction();
    public class Menu
    {
        protected class Record
        {
            public Record(string str, MenuAction action)
            {
                this._case = str;
                this._action = action;
            }
            public string _case;
            public MenuAction _action;
        }
        protected List<Record>recs;
        protected bool menuDlgState;
        protected string Header;
        public Menu()
        {
            recs = new List<Record>();
            menuDlgState = false;
            Header = "";
        }
        public static void DisplayException(Exception ex)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("An exception of type: ");
            sb.Append(ex.GetType().FullName);
            sb.Append("\n");
            sb.Append(ex.Message);
            Console.WriteLine(sb.ToString());
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();

        }
        public void AddRecord(string str, MenuAction action)
        {
            recs.Add(new Record(str, action));
        }
        public void SetHeader(string s)
        {
            Header = s;
        }
        public virtual void Show()
        {
            if(Header != "")
            {
                Console.WriteLine(Header);
            }
            for (int i = 0; i < recs.Count; ++i)
            {
                Console.WriteLine(recs[i]._case);
            }
        }

        public virtual int GetChoiceDlg(out string s)
        {
            Console.WriteLine();
            int choice = -1;
            Console.Write("Make a choice: ");
            s = Console.ReadLine();
            Int32.TryParse(s, out choice);
            return choice;
        }

        public virtual void MakeAction(int choice)
        {
            if (choice < 0 || choice >= recs.Count)
                return;
            recs[choice]._action();
        }

        public virtual void StartDlg()
        {
            int choice = 0;
            string s = "";
            menuDlgState = true;
            while (menuDlgState)
            {
                Console.Clear();
                this.Show();
                if(choice < 0 || choice > recs.Count + 1)
                {
                    Console.WriteLine("\nIncorrect input detected: " + s);
                }
                choice = this.GetChoiceDlg(out s) - 1;
                this.MakeAction(choice);
            }
        }
        public void EndDlg()
        {
            menuDlgState = false;
        }
    }
}
