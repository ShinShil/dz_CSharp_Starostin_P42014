﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace lk9_dz1
{
    class Game
    {
        public delegate void TableChange();
        static public event TableChange TableChangeEvent;

        private Table table;
        private bool gameState;
        private int activeTable;
        private MemoryStream[] tablesStreams = new MemoryStream[10];
        private BinaryFormatter BF;

        private void ChangeTable(int i)
        {
            BF.Serialize(tablesStreams[activeTable], table);
            
            table = null;
            try {
                tablesStreams[i].Seek(0, SeekOrigin.Begin);
                table = (Table)BF.Deserialize(tablesStreams[i]);
            }
            catch(Exception ex)
            {
                //Console.WriteLine(ex.Message);
                table = new Table();
            }
            activeTable = i;
            Console.Clear();
            table.Show(activeTable);
            TableChangeEvent();
        }
        public bool EventHandlerKeyPressed(ConsoleKeyInfo info)
        {
            if(info.Modifiers == ConsoleModifiers.Shift)
                switch(info.Key)
                {
                    case ConsoleKey.F1:
                        ChangeTable(0);
                        return true;
                    case ConsoleKey.F2:
                        ChangeTable(1);
                        return true;;
                    case ConsoleKey.F3:
                        ChangeTable(2);
                        return true;;
                    case ConsoleKey.F4:
                        ChangeTable(3);
                        return true;;
                    case ConsoleKey.F5:
                        ChangeTable(4);
                        return true;;
                    case ConsoleKey.F6:
                        ChangeTable(5);
                        return true;;
                    case ConsoleKey.F7:
                        ChangeTable(6);
                        return true;;
                    case ConsoleKey.F8:
                        ChangeTable(7);
                        return true;;
                    case ConsoleKey.F9:
                        ChangeTable(8);
                        return true;;
                    case ConsoleKey.F10:
                        ChangeTable(9);
                        return true;;
                    case ConsoleKey.F11:
                        table.gameState = Table.States.End;
                        return true;
                    case ConsoleKey.F12:
                        gameState = false;
                        TableChangeEvent();
                        return false;
                    default:
                        return false;
                }
            return false;
        }
        public Game()
        {
            for(int i = 0; i<10; ++i)
            {
                tablesStreams[i] = new MemoryStream();
            }
            Table.KeyPressed += new Table.KeyPress(EventHandlerKeyPressed);
            BF = new BinaryFormatter();
            activeTable = 0;
            gameState = false;
            table = new Table();
        }
        ~Game()
        {
            for(int i = 0; i<10;++i)
            {
                tablesStreams[i].Close();
            }
        }
        public void GameStart()
        {
            gameState = true;
        }
        public void GameGo()
        {
            while (gameState)
                ShowTable();
        }
        public void ShowTable()
        {
            Console.Clear();
            table.Show(activeTable);
        }
    }
}
