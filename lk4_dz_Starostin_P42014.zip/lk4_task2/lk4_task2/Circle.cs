﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Circle:Ellips
    {
        public Circle() : base() { }
        public Circle(double radius) : base(radius, radius) { }
    }
}
