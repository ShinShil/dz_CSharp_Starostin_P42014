﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{

    class Program
    {
        //доделать эллипс, от эллипса круг и трапецию
        static void Main(string[] args)
        {
            Rectangle a = new Rectangle(2, 2);
            Console.WriteLine(a.S);
            Console.WriteLine(a.P);

            Circle cirk = new Circle(5);
            Console.WriteLine("\nПлощадь круга: {0}, длина окружности круга: {1}", cirk.S, cirk.P);

            Square sq = new Square(5);
            Console.WriteLine("\nПлощадь квадрата: {0}, периметр квадрата: {1}", sq.S, sq.P);
            Console.WriteLine("Угадайте, какая длина квадрата?");
            char ch;
            char.TryParse(Console.ReadLine(), out ch);
            if (ch != '5')
                Console.WriteLine("Неверный ответ, т.к. для квадрата P = 4*a; S = a*a, где a - сторона квадрата, то a = 5");
            else
                Console.WriteLine("Верно, Вы либо очень везучи, либо помните пару формул из геометрии начальной школы:)");

            Romb rmb = new Romb(5, 1);
            Console.WriteLine("\nПлощадь ромба: {0}, периметер ромба: {1}", rmb.S, rmb.P);

            try
            {
                Triangle tr = new Triangle(5, 2, 2);
            }
            catch(GeometryException ex)
            {
                ex.ShowError();
            }
            finally
            {
                Console.WriteLine("\nAll exceptions was succesfully catched");
            }
        }
    }
}
