﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
   abstract  class GeometryFigure
    {
        public decimal square;
        public decimal perimetr;

        public abstract void CountSquare();
        public abstract void CountPerimetr();

        public decimal S
        {
            get { return square; }
        }

        public decimal P
        {
            get { return perimetr; }
        }
    }
}
