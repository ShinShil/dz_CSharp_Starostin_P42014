﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Rectangle: Parallelogram
    {
        public Rectangle() : base() { }
        public Rectangle(decimal a, decimal b) : base(a, b, (decimal)Math.PI / 2) { }
    }
}
