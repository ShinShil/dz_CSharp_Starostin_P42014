﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Triangle : GeometryFigure
    {
        public decimal a;
        public decimal b;
        public decimal c;

        public Triangle()
        {
            this.a = 0;
            this.b = 0;
            this.c = 0;
            CountPerimetr();
            CountSquare();
        }

        public Triangle(decimal a, decimal b, decimal c)
        {
            if (a + b <= c || a + c <= b || c + b <= a)
                throw new GeometryException("Unbelibiable triangle - the summ of two sides lower then the third");
            this.a = a;
            this.b = b;
            this.c = c;
            CountPerimetr();
            CountSquare();
        }

        public override void CountPerimetr()
        {
            perimetr = a + b + c;
        }
        public override void CountSquare()
        {
            double geron = (double)(P / 2 * (P / 2 - a) * (P / 2 - b) * (P / 2 - c));
            square = (decimal)Math.Sqrt(geron);
        }
    }
}
