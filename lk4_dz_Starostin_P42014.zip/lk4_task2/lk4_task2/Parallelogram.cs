﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Parallelogram:GeometryFigure
    {
        public decimal a;
        public decimal b;
        public decimal alpha;

        public Parallelogram()
        {
            this.a = 0;
            this.b = 0;
            this.alpha = 0;
            CountPerimetr();
            CountSquare();
        }

        public Parallelogram(decimal a, decimal b, decimal alpha)
        {
            this.a = a;
            this.b = b;
            this.alpha = alpha;
            CountPerimetr();
            CountSquare();
        }

        public override void CountPerimetr()
        {
            perimetr = (a + b) * 2;
        }
        public override void CountSquare()
        {
            square = a * b * (decimal)Math.Sin((double)alpha);
        }
    }
}
