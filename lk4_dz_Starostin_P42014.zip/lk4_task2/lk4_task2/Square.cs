﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Square:Rectangle
    {
        public Square() : base() { }
        public Square(decimal a) : base(a, a) { }
    }
}
