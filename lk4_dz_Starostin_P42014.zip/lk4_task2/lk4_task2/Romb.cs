﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Romb:Parallelogram
    {
        public Romb() : base() { }
        public Romb(decimal a, decimal alpha) : base(a, a, alpha) { }
    }
}
