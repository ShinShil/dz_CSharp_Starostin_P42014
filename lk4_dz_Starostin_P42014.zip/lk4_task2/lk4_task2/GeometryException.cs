﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class GeometryException:Exception
    {
       private string msg;
        public GeometryException(string str)
        {
            msg = str;
        }

        public void ShowError()
        {
            Console.WriteLine("\n-----------------------------------------------");
            Console.WriteLine("!!!Error!!!");
            Console.WriteLine(msg);
            Console.WriteLine("-----------------------------------------------\n");
        }
    }
}
