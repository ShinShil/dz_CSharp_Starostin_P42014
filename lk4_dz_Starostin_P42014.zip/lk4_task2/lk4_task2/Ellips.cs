﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Ellips : GeometryFigure
    {
        public double a;
        public double b;

        public Ellips()
        {
            a = 0;
            b = 0;
            CountPerimetr();
            CountSquare();
        }
        public Ellips(double a, double b)
        {
            this.a = a;
            this.b = b;
            CountPerimetr();
            CountSquare();
        }

        public override void CountPerimetr()
        {
            perimetr = (decimal)(4 * (Math.PI*a*b + Math.Pow((a- b),2)) / (a+b));
        }
        public override void CountSquare()
        {
            square = (decimal)(Math.PI * a * b);
        }
    }
}
