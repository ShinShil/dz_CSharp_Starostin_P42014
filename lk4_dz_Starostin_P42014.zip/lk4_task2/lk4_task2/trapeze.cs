﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task2
{
    class Trapeze:GeometryFigure
    {

        public double a;
        public double b;
        public double c;
        public double d;
        public double h;

        public Trapeze()
        {
            a = 0;
            b = 0;
            CountPerimetr();
            CountSquare();
        }
        public Trapeze(double a, double b, double c, double d, double h)
        {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.h = h;
            CountPerimetr();
            CountSquare();
        }

        public override void CountPerimetr()
        {
            perimetr = (decimal)(a+b+c+d);
        }
        public override void CountSquare()
        {
            square = (decimal)((a + b)/2*h);
        }
    }
}
