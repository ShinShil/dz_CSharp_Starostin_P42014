﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk4_task3
{
    class Program
    {
        public interface I_Good {
            void Add(GoodsType type, Charecteristic character);
        }
        public interface I_Perishable:I_Good
        {
            Boolean remaingDays { get; }
        }
        public interface  I_Eighteen : I_Good
        {

        }
        public interface I_EasyFire : I_Good
        {

        }
        public interface I_EasyBreak : I_Good
        {

        }

        public enum GoodsType
        {
            Chemistry = 0,
            Products = 1

        }
       public enum Charecteristic
        {
            EasyFire = 0,
            EasyBreak = 1,
            Eighteen = 2,
            Perishable = 3
        }
        class Good: I_EasyBreak, I_Eighteen, I_Perishable, I_EasyFire  
        {
            private string[] characters = new string[2];
            private string[] types = new string[4];

            public string Name;
            public string Cost;
            public string Amount;
            GoodsType Type;
            List<Charecteristic> Character;
            public event EventHandler addGood;
            public event EventHandler sellGood;
            public event EventHandler gamyGood;
            public event EventHandler giftGood;

            public void Add(GoodsType type, Charecteristic character)
            {
                addGood(this, EventArgs.Empty);
            }
            public void Sell()
            {
                sellGood(this, EventArgs.Empty);
            }
            public void Lose()
            {
                gamyGood(this, EventArgs.Empty);
            }
            public void Gift()
            {
                giftGood(this, EventArgs.Empty);
            }
            public Boolean remaingDays
            {
                get
                {
                    return false;
                }
            }
        }
       static public class ControlThread
        {
            static  public double balance = 0;
            static public int newGoods = 0;
            static public int soldGoods = 0;
            static public int gamyGoods = 0;
            static public int giftGoods = 0;

            static public void NewGood(object Sender, EventArgs e)
            {
                ++newGoods;
            }
            static public void SoldGoods(object Sender, EventArgs e)
            {
                ++soldGoods;
            }
            static public void GamyGoods(object Sender, EventArgs e)
            {
                ++gamyGoods;
            }
            static public void GiftGoods(object Sender, EventArgs e)
            {
                ++giftGoods;
            }

            static public void ShowState()
            {
                DateTime now = new DateTime();
                Console.WriteLine("The state");
                Console.WriteLine("------------------------------");
                Console.WriteLine(now.Date);
                Console.WriteLine("New:  {0}", newGoods);
                Console.WriteLine("Sold: {0}", soldGoods);
                Console.WriteLine("Gift: {0}", giftGoods);
                Console.WriteLine("Gamy: {0}", gamyGoods);
                Console.WriteLine("------------------------------\nPress any key to continue. . .");
                Console.ReadKey();
            }
        }
        public class GoodsException:Exception
        {
            string msg;
            public GoodsException(string str)
            {
                msg = str;
            }
            public void ShowError()
            {
                Console.WriteLine("\n--------------------------------");
                Console.WriteLine("!!!Error!!!");
                Console.WriteLine(msg);
                Console.WriteLine("---------------------------------\n");
            }
        }
        class Menu
        {
            static public void Show() {
                Console.Clear();
                Console.WriteLine("1.Add good");
                Console.WriteLine("2.Sell good");
                Console.WriteLine("3.Gamy good");
                Console.WriteLine("4.Gift good");
                Console.WriteLine("5.Show the state");
                Console.WriteLine("6.Exit");
                Console.Write("\nYour choice: ");
            }
            static public int WorkWithTheChoice(ref Good a)
            {
                int choice;
                if(!int.TryParse(Console.ReadLine(), out choice))
                    throw new GoodsException("Admin choose the impossible variant");
                switch(choice)
                {
                    case 1:
                        a.Add(0,0);
                        break;
                    case 2:
                        a.Sell();
                        break;
                    case 3:
                        a.Lose();
                        break;
                    case 4:
                        a.Gift();
                        break;
                    case 5:
                        ControlThread.ShowState();
                        break;

                }
                return choice==6?0:choice;
            }
        }
        static void Main(string[] args)
        {
            Good a = new Good();
            a.gamyGood += new EventHandler(ControlThread.GamyGoods);
            a.giftGood += new EventHandler(ControlThread.GiftGoods);
            a.sellGood += new EventHandler(ControlThread.SoldGoods);
            a.addGood += new EventHandler(ControlThread.NewGood);

            do
            {
                Menu.Show();
            } while ((Menu.WorkWithTheChoice(ref a))>0);
        }
    }
}
