﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lr1
{
    class Program
    {
        const int EXIT = 3;

        static void Pause()
        {
            Console.WriteLine("Нажмите любую клавишу");
            Console.ReadKey();
        }

       static void task1()
        {
            int a, b;
            Console.Clear();
            Console.WriteLine("Введите два целых положительных числа А и В(A<B) ");
            Console.Write("A: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("B: ");
            b = Convert.ToInt32(Console.ReadLine());
            if(a >= b)
            {
                Console.WriteLine("Число А должон быть меньше числа В");
                Pause();
                return;
            }
            for(int i = a; i < b; ++i)
            {
                for(int j = 0; j < i; ++j)
                {
                    Console.Write(i + ";");
                }
                Console.WriteLine();
            }
            Pause();
        }

        static void task2()
        {
            Console.Clear();
            int n;
            int firstLetter = 65;
            Console.Write("Введите количество строк: ");
            n = Convert.ToInt32(Console.ReadLine());
            if(n<=0)
            {
                Console.WriteLine("Количество строк должно быть положительным целым числом");
            }
            Console.WriteLine();
            for(int i = 0; i< n; ++i)
            {
                for (int j = 0; j<5; ++j)
                {
                    char ch = (char)(firstLetter + j);
                    Console.Write(ch + " ");
                }
                Console.WriteLine();
                ++firstLetter;
            }
            Console.WriteLine();
            Pause();
        }

        static void task3()
        {
            Console.Clear();
            string str;
            Console.WriteLine("Введите целое не отрицательное число: ");
            str = Console.ReadLine();
            for(int i = 0; i<str.Length; ++i)
            {
                if (!Char.IsNumber(str[i]))
                {
                    Console.WriteLine("Некорректный ввод, см. условие ввода");
                    Pause();
                    return;
                }
            }
            int delta = 0;
            for(int i = str.Length - 1; i>=str.Length/2; --i)
            {
                if(str[i]!=str[delta])
                {
                    Console.WriteLine("Не палиндром");
                    Pause();
                    return;
                }
                ++delta;
            }
            Console.WriteLine("Палиндром");
            Pause();
            return;
        }

        static void task4()
        {
            Console.Clear();
            string[] mas = { "17", "67", "99"};
            Console.WriteLine("Допустимые значения: 17, 67, 99");
            string user = Console.ReadLine();
            switch(user)
            {
                case "17":
                case "67":
                case "99":
                    Console.WriteLine("Введённое значение удовлетворяет условиям");
                    break;
                default:
                    Console.WriteLine("Введённое значение не удовлетворяет условиям");
                    break;
            }
            Pause();
            return;
        }

        static void task6()
        {
            Console.Clear();
            decimal x = 1;
            decimal step = (decimal)((10.0 - 1.0) / 11.0);
            Console.WriteLine("Диапазон: 1..10");
            Console.WriteLine("Количество значений: 11");
            Console.WriteLine("Выражение: Х - 1");
            Console.WriteLine("Рассчитанный шаг: " + step);
            Console.Write("Значения: ");
            for (int  i = 0; i<11; ++i)
            {
                Console.Write(Math.Round(x - 1, 2) + " ");
                x += step;
            }
            Console.WriteLine();
            Pause();
        }

        static void task7()
        {
            Console.Clear();
            Console.Write("Введите целое число: ");
            string num = Console.ReadLine();
            int first = num[0] == '-' ? 1 : 0;
            for (int i = first; i<num.Length; ++i)
            {
                if (!Char.IsNumber(num[i]))
                {
                    Console.WriteLine("Вы ввели не число;");
                    Pause();
                    return;
                }
            }
            int min, max;
            min = Convert.ToInt32(num[first].ToString());
            max = Convert.ToInt32(num[first].ToString());

            for (int i = first; i < num.Length; ++i)
            {
                if (min > Convert.ToInt32(num[i].ToString()))
                    min = Convert.ToInt32(num[i].ToString());


                if (max < Convert.ToInt32(num[i].ToString()))
                    max = Convert.ToInt32(num[i].ToString());
            }

            Console.WriteLine("\nМаксимальная цифра: " + max);
            Console.WriteLine("Минимальная цифра: " + min);
            Console.WriteLine("Сумма максимальной и минимальной цифры в введённом числе: {0}\n", min+max);

            Pause();
        }

        static void task8()
        {
            Console.Clear();
            UInt64 summ = 1;
            UInt64 num = 1;
            UInt64[] fibo = new UInt64[100];
            fibo[0] = 1;
            for(int i = 1; i<100; ++i)
            {
                fibo[i] = num;
                num = fibo[i] + fibo[i - 1];
                summ += fibo[i];
            }
            Console.WriteLine("Сумма первых 100 чисел Фиббоначи: " + summ);
            Pause();
        }

        static void task9()
        {
            Console.Clear();
            Console.WriteLine("Будем рассчитыват сумму ряда: shX\nРекомендую такие значения: X - 1, Точность - 2, Граница - 0,12");
            Console.Write("Введите X: ");
            decimal x = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Введите точность: ");
            int k = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите граничное число: ");
            decimal e = Convert.ToDecimal(Console.ReadLine());
            decimal summ = x;
            UInt64 fact = 1;
            int slagaemie = 1;
            if(k>9)
            {
                Console.WriteLine("Нету макрополстановок в С#");
                Pause();
                return;
            }
            for(UInt64 i = 3; i>0; i+=2)
            {
                ++slagaemie;
                x = x * x * x;
                fact = fact * (i - 1) * i;
                summ += x / fact;
                if(x/fact<e)
                    break;
                if(i == 999)
                {
                    Console.WriteLine("Слишком затратно для консольки :)");
                    Pause();
                    return;
                }
            }
            Math.Round(summ, k);
            switch(k)
            {
                case 1: Console.WriteLine("Summ: {0:0.#}", summ); break;
                case 2: Console.WriteLine("Summ: {0:0.##}", summ); break;
                case 3: Console.WriteLine("Summ: {0:0.###}", summ); break;
                case 4: Console.WriteLine("Summ: {0:0.####}", summ); break;
                case 5: Console.WriteLine("Summ: {0:0.#####}", summ); break;
                case 6: Console.WriteLine("Summ: {0:0.######}", summ); break;
                case 7: Console.WriteLine("Summ: {0:0.#######}", summ); break;
                case 8: Console.WriteLine("Summ: {0:0.########}", summ); break;
                case 9: Console.WriteLine("Summ: {0:0.#########}", summ); break;

            }

            Console.WriteLine("Количество слагаемых: " + slagaemie);
            Pause();
        }

        static void Main(string[] args)
        {
            int choice;
            do
            {
                Console.Clear();
                Console.WriteLine("1.Введите два целых положительных числа А и В");
                Console.WriteLine("2.Вывести n строк");
                Console.WriteLine("3.Проверить, является ли число перевёртышем");
                Console.WriteLine("4.Проверить, попадает ли введённое значение в разрешённый список");
                Console.WriteLine("5.В задании опечатка, после номера 4 идёт номер 6, пятый номер отсутствует");
                Console.WriteLine("6.Вывод значений согласно исходным данным варианта");
                Console.WriteLine("7.Найти сумму минимальной и максимальнйо цифры в числе");
                Console.WriteLine("8.Рассчитать сумму 100 чисел ряда Фибонначи");
                Console.WriteLine("9.Рассчитать сумму ряда Тейлора");
                Console.WriteLine("10.Выход");
                choice = Convert.ToInt32(Console.ReadLine());
                switch(choice)
                {
                    case 1: task1(); break;
                    case 2: task2(); break;
                    case 3: task3(); break;
                    case 4: task4(); break;
                    case 5: break;
                    case 6: task6(); break;
                    case 7: task7(); break;
                    case 8: task8(); break;
                    case 9: task9(); break;
                }
            } while (choice != 10);
        }
    }
}
