﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.SpyDuck
{
    class SpyDuck : Duck.Duck
    {
        public SpyDuck() : this("default") { }
        public SpyDuck(string townName)
        {
            GoToTown(townName);
        }
        public override void Display()
        {
            Console.WriteLine("Spy duck has been drawn");
        }
        public void GoToTown(string townName = "default")
        {
            switch (townName)
            {
                case "Base":
                    fly = new Duck.RFly();
                    say = new Duck.RSay();
                    swim = new Duck.RSwim();
                    break;
                case "Gray":
                    fly = new GrayDuck.GrayFly();
                    say = new GrayDuck.GraySay();
                    swim = new GrayDuck.GraySwim();
                    break;
                case "Wooden":
                    fly = new Common.RNull();
                    say = new Common.RNull();
                    swim = new WoodenDuck.WoodenSwim();
                    break;
                default:
                    fly = new SpyFly();
                    say = new SpySay();
                    swim = new SpySwim();
                    break;
            }
        }
    }
}
