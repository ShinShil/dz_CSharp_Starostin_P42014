﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.SpyDuck
{
    class SpySay:Common.ISay
    {
        public void Say()
        {
            Console.WriteLine("Spy duck is say");
        }
    }
}
