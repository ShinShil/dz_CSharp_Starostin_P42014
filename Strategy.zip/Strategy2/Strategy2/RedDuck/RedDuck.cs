﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.RedDuck
{
    class RedDuck:GrayDuck.GrayDuck
    {
        public RedDuck():base()
        {

        }

        public override void Display()
        {
            Console.WriteLine("Red duck has been drawn");
        }
    }
}
