﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.GrayDuck
{
    class GrayDuck:Duck.Duck
    {
        public GrayDuck()
        {
            say = new GraySay();
            fly = new GrayFly();
            swim = new GraySwim();
        }
        public override void Display()
        {
            Console.WriteLine("Gray duck has been drawn");
        }
    }
}
