﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.GrayDuck
{
    class GrayFly: Common.IFly
    {
        public void Fly()
        {
            Console.WriteLine("Gray duck is flying");
        }
    }
}
