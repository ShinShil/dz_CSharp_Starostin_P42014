﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.GrayDuck
{
    class GraySwim:Common.ISwim
    {
        public void Swim()
        {
            Console.WriteLine("Gray duck is swimming");
        }
    }
}
