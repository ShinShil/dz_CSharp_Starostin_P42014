﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.GrayDuck
{
    class GraySay:Common.ISay
    {
        public void Say()
        {
            Console.WriteLine("Gray duck say: \"Crya-Crya\"");
        }
    }
}
