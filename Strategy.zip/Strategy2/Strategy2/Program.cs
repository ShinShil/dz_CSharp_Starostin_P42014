﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2
{
    class Program
    {
        static void Main(string[] args)
        {
            Duck.Duck[] d = new Duck.Duck[6];
            d[0] = new Duck.Duck();
            d[1] = new GrayDuck.GrayDuck();
            d[2] = new WoodenDuck.WoodenDuck();
            d[3] = new GrayDuck.GrayDuck();
            d[4] = new RedDuck.RedDuck();
            d[5] = new IronDuck.IronDuck();

            for (int i = 0; i < 6; ++i)
            {
                d[i].Display();
                d[i].Fly();
                d[i].Say();
                d[i].Swim();
                Console.WriteLine("----------------");
            }

            //string townName = "";
            //SpyDuck.SpyDuck sd = new SpyDuck.SpyDuck();
            //while(townName != "exit")
            //{
            //    Console.Clear();
            //    Console.Write("Введите название города: ");
            //    townName = Console.ReadLine();
            //    sd.GoToTown(townName);
            //    sd.Display();
            //    sd.Swim();
            //    sd.Fly();
            //    sd.Say();
            //    Console.WriteLine("Нажмите любую клавишу...");
            //    Console.ReadKey(true);
            //}
        }
    }
}
