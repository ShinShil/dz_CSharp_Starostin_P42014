﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.Duck
{
    class RSwim:Common.ISwim
    {
        public void Swim()
        {
            Console.WriteLine("Base duck is swimming");
        }
    }
}
