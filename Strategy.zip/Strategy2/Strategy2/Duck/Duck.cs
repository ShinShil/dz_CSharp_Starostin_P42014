﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Strategy2.Common;

namespace Strategy2.Duck
{
    class Duck
    {
        public IFly fly;
        public ISay say;
        public ISwim swim;
        public Duck()
        {
            say = new RSay();
            fly = new RFly();
            swim = new RSwim();
        }
        public virtual void Display()
        {
            Console.WriteLine("Base duck has drawn to the screen");
        }
        public void Say()
        {
            say.Say();
        } 
        public void Fly()
        {
            fly.Fly();
        }
        public virtual void Swim()
        {
            swim.Swim();
        }
    }
}
