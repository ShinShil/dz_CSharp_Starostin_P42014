﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.Duck
{
    class RSay: Common.ISay
    {
        public void Say()
        {
            Console.WriteLine("Base duck say");
        }
    }
}
