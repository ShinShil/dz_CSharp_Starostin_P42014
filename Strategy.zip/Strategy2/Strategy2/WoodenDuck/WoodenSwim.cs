﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.WoodenDuck
{
    class WoodenSwim:Common.ISwim
    {
        public void Swim()
        {
            Console.WriteLine("The wooden duck is bobing on the waves");
        }
    }
}
