﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.WoodenDuck
{
    class WoodenDuck:Duck.Duck
    {
        public WoodenDuck()
        {
            fly = new Common.RNull();
            say = new Common.RNull();
            swim = new WoodenSwim();
        }
        public override void Display()
        {
            Console.WriteLine("Wooden duck has been drawn");
        }
    }
}
