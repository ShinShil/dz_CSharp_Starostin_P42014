﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.IronDuck
{
    class IronDuck:WoodenDuck.WoodenDuck
    {
        public override void Display()
        {
            Console.WriteLine("Iron duck has been drawn");
        }
        public IronDuck()
        {
            fly = new Common.RNull();
            say = new Common.RNull();
            swim = new Common.RNull();

        }
    }
}
