﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy2.Common
{
    class RNull: IFly, ISay, ISwim
    {
        public void Fly()
        {

        }
        public void Say()
        {

        }


        public void Swim()
        {

        }
    }
}
