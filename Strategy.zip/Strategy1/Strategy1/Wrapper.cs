﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy1
{
    abstract class Wrapper
    {
        protected PrintAction defaultAction;
        public delegate void PrintAction();
        public virtual void Say()
        {
            defaultAction();
        }
        public virtual void Fly()
        {
            defaultAction();
        }
        public virtual void Swim()
        {
            defaultAction();
        }

        protected void Wrap(PrintAction action = null)
        {
            if(action != null)
            {
                action();
            }else
            {
                if(defaultAction!=null)
                {
                    defaultAction();
                }
                else
                {
                    return;
                }
            }
        }
       
    }
}
