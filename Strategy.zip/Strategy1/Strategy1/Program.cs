﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy1
{
    class Program
    {
        //+нет огрничений по интерфейсу
        //+можно передать любую функцию
        //+может быть полезно, если уметь создавать mix-классы, см. п2
        //+в делегаты можно укладывать несколько функций
        //-сложнее поддерживать, т.к. нету такой жёсткой привязки
        //-нужно потратить больше времени на продумывание архитектуры, для достижения максимальной эффективности, т.е. не использовать say, а использовать чисто типы делегатов void(), void(int), bool() 
        static void Main(string[] args)
        {
            Duck d = new Duck();
            d.Say();
            d.Swim();
            d.Fly();
            WoodenDuck wd = new WoodenDuck();
            wd.sayAction = new Wrapper.PrintAction(Default);
            wd.sayAction += new Wrapper.PrintAction(SecondDel);
            wd.Say();
        }
        public static void Default()
        {
            Console.WriteLine("This duck can't say");
        }
        public static void SecondDel()
        {
            Console.WriteLine("But, sometimes it can say:)");
        }
    }
}
