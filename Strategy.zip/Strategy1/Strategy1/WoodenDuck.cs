﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy1
{
    class WoodenDuck:Duck 
    {
        public PrintAction sayAction;

        public WoodenDuck(PrintAction say = null)
        {
            sayAction = say;
        }
        public virtual void Say()
        {
            Wrap(sayAction);
        }
        public virtual void Swim()
        {
            Console.WriteLine("Simple duck swims");
        }
        public virtual void Fly()
        {
            Console.WriteLine("Simple duck flys");
        }
    }
}
