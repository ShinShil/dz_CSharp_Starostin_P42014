﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk5_dz1
{
    static class Structures
    {
        #region structures
        struct Good
        {
            public Good(string name, int code, double cost)
            {
                this.name = name;
                this.code = code;
                this.cost = cost;
            }
            string name;
            int code;
            readonly public double cost;
            public void Show()
            {
                Console.WriteLine("Код: {0}, наименование: {1}, цена: {2}", code, name, cost);
            }
        }
        struct Client
        {
            public Client(string fio, string addres, string tel)
            {
                this.fio = fio;
                this.addres = addres;
                this.tel = tel;
                this.summaryCost = 0;
                this.orderAmount = 0;
                ++code;
            }
            public void RefreshCode()
            {
                code = 0;
            }
            private static int code = 0;
            public int Code
            {
                get
                {
                    return code;
                }
            }
            string fio;
            string addres;
            string tel;
            int orderAmount;
            double summaryCost;
            public void Show()
            {
                Console.WriteLine("Клиент {0}, ФИО {1}, адрес {2}, телефон {3}, количество заказов {4}, стоимость заказов {5}", code, fio, addres, tel, orderAmount, summaryCost);
            }
        }
        struct RequestItem
        {
            Good good;
            int goodAmount;
        }
        struct Request
        {
            Request(int code, Client client, DateTime date)
            {
                this.orderCode = code;
                this.client = client;
                this.date = date;
                goods = new List<Good>();
            }
            Request(int code, Client client, DateTime date, List<Good> goods)
            {
                this.orderCode = code;
                this.client = client;
                this.date = date;
                this.goods = goods;
            }
            void AddGood(Good good)
            {
                goods.Add(good);
            }
            int orderCode;
            Client client;
            DateTime date;
            List<Good> goods;
            public double SummaryCost
            {
                get
                {
                    double res = 0;
                    for (int i = 0; i < goods.Count; ++i)
                    {
                        res += goods[i].cost;
                    }
                    return res;
                }
            }
            void Show()
            {
                Console.WriteLine("Заказ {0}, клиент {1}, дата {2}, товаров {3}, стоимость {4}", orderCode, client.Code, date, goods.Count, SummaryCost);
            }
        }
        #endregion

        public static void EntryPoint()
        {
            Client client = new Client("smb", "Andrew 15", "123");
            Good good = new Good("good1", 1, 14);
            client.Show();
            good.Show();
        }
    }
}
