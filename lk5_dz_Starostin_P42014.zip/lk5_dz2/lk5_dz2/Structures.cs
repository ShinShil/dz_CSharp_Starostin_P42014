﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk5_dz2
{
    static class Structures
    {
        #region structures
        struct Good
        {
            public Good(string name, int code, double cost)
            {
                this.name = name;
                this.code = code;
                this.cost = cost;
            }
            string name;
            int code;
            readonly public double cost;
            public void Show()
            {
                Console.WriteLine("Код: {0}, наименование: {1}, цена: {2}", code, name, cost);
            }
        }
        struct Client
        {
            public Client(string fio, string addres, string tel)
            {
                this.fio = fio;
                this.addres = addres;
                this.tel = tel;
                this.summaryCost = 0;
                this.orderAmount = 0;
                this.type = ClientType.NotImportant;
                ++code;
            }
            public void RefreshCode()
            {
                code = 0;
            }
            private static int code = 0;
            public int Code
            {
                get
                {
                    return code;
                }
            }
            ClientType type;
            string fio;
            string addres;
            string tel;
            int orderAmount;
            double summaryCost;
            string PrintType(ClientType type)
            {
                switch(type)
                {
                    case ClientType.NotImportant:
                        return "Not Important";
                    case ClientType.Important:
                        return "Important";
                    case ClientType.Expensive:
                        return "Expensive";
                }
                return "Not defined";
            }
            public void Show()
            {
                Console.WriteLine("Клиент {0}, ФИО {1}, адрес {2}, телефон {3}, количество заказов {4}, стоимость заказов {5}, важность {6}", code, fio, addres, tel, orderAmount, summaryCost, PrintType(type));
            }
        }
        struct RequestItem
        {
            Good good;
            int goodAmount;
        }
        struct Request
        {
            Request(int code, Client client, DateTime date)
            {
                this.orderCode = code;
                this.client = client;
                this.date = date;
                goods = new List<Good>();
            }
            Request(int code, Client client, DateTime date, List<Good> goods)
            {
                this.orderCode = code;
                this.client = client;
                this.date = date;
                this.goods = goods;
            }
            void AddGood(Good good)
            {
                goods.Add(good);
            }
            int orderCode;
            Client client;
            DateTime date;
            List<Good> goods;
            public double SummaryCost
            {
                get
                {
                    double res = 0;
                    for (int i = 0; i < goods.Count; ++i)
                    {
                        res += goods[i].cost;
                    }
                    return res;
                }
            }
            void Show()
            {
                Console.WriteLine("Заказ {0}, клиент {1}, дата {2}, товаров {3}, стоимость {4}", orderCode, client.Code, date, goods.Count, SummaryCost);
            }
        }
        #endregion

        #region enums
        enum GoodType
        {
            type1 = 0,
            type2 = 1,
            type3 = 2
        }
        enum ClientType
        {
            Important = 0,
            NotImportant = 1,
            Expensive = 2
        }
        enum PayType
        {
            ByCard = 0,
            ByMoney = 1,
            ByWork = 2
        }
        #endregion
        public static void EntryPoint()
        {
            Client client = new Client("smb", "Andrew 15", "123");
            Good good = new Good("good1", 1, 14);
            client.Show();
            good.Show();
        }
    }
}
