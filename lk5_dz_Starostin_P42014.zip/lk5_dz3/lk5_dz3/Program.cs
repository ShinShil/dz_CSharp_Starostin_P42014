﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk5_dz3
{
    class Program
    {
        public delegate bool IsEqual(Object obj1, Object obj2);
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            Console.Write("Элементы массива: ");
            object[] tml2 = new object[5] { 1, "line", 6, "longstr", 8 };
            for (int i = 0; i < 5; ++i) { 
                Console.Write(tml2[i] + " ");
            }
            Console.Write("\n\nВведите элемент для поиска: ");
            string key = Console.ReadLine();
            object[] tmp = new object[5];
            object res = Search(tml2, key, new IsEqual(IsEqualMet));
            int key2;
            object res2 = null;
            if (Int32.TryParse(key, out key2))
                 res2 = Search(tml2, key2, new IsEqual(IsEqualMet));
            if (res == null && res2 == null)
                Console.WriteLine("\nЭлемент не найден");
            else {
                if (res != null)
                    Console.WriteLine("\n" + res + " элемент найден, тип - " + res.GetType());
                if(res2 != null)
                    Console.WriteLine("\n" + res2 + " элемент найден, тип - " + res2.GetType());
            }
        }

        static public Object Search(Object[] arr,object key, IsEqual isElem)
        {
            foreach (Object elem in arr)
                if (isElem(elem, key))
                    return elem;
            return null;
        }

        static public bool IsEqualMet(object i1, object i2)
        {
            if (i1.Equals(i2))
                return true;
            else return false;
        }
    }
}
