﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
namespace lk8_dz3
{
    public interface XMLEnable
    {
        void SaveAsXmlNode(ref XmlTextWriter writer);
    }
    static class Dialogs
    {
        static public void DisplayException(Exception ex)
        {
            Console.WriteLine("\nType Exception: " + ex.GetType());
            Console.WriteLine(ex.Message + "\n");
            Console.WriteLine(ex.StackTrace + "\n\n");
            Console.WriteLine("Source: " + ex.Source + "\n\n");
        }
    }
}
