﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;

namespace lk8_dz3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("\n\tXmlDocument\n");
                string path = "C:\\test\\order1.xml";
                XmlDocument doc = new XmlDocument();
                doc.Load(path);
                XmlNodeList orders = doc.SelectNodes("/order");
                int i = 1;
                foreach (XmlNode node in orders)
                {
                    Console.WriteLine("Order " + i++);
                    Console.WriteLine(node.Name);
                    XmlNodeList goods = node.SelectNodes("goods/good");
                    foreach (XmlNode good in goods)
                    {
                        Console.WriteLine("\tGood ");
                        Console.WriteLine("\t\tname: " + good.SelectSingleNode("name").InnerXml);
                        Console.WriteLine("\t\tcost: " + good.SelectSingleNode("cost").InnerXml);
                        Console.WriteLine("\t\tcurrency: " + good.SelectSingleNode("currency").InnerXml);
                        Console.WriteLine("\t\tamount: " + good.SelectSingleNode("amount").InnerXml);
                        foreach (XmlAttribute attr in good.Attributes)
                            Console.WriteLine("\t\tAdditional info: \"{0}\":\"{1}\" ", attr.Name, attr.Value);
                    }
                }

                Console.WriteLine("-------------------------------------------------");
                Console.WriteLine("\n\tXmlReader\n");
                using (XmlTextReader reader = new XmlTextReader(path))
                {
                    int j = 1;
                    reader.WhitespaceHandling = WhitespaceHandling.None;
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                            switch (reader.Name)
                            {
                                case "order":
                                    Console.WriteLine("Order " + j++);
                                    break;
                                case "good":
                                    Console.WriteLine("\tGood");
                                    if (reader.AttributeCount > 0)
                                    {
                                        while (reader.MoveToNextAttribute())
                                            Console.WriteLine("\t\tAdditional info: \"{0}\":\"{1}\" ", reader.Name, reader.Value);
                                    }
                                    break;
                                case "name":
                                    Console.WriteLine("\t\tname: " + reader.ReadString());
                                    break;
                                case "currency":
                                    Console.WriteLine("\t\tcurrency: " + reader.ReadString());
                                    break;
                                case "amount":
                                    Console.WriteLine("\t\tamount: " + reader.ReadString());
                                    break;
                                case "cost":
                                    Console.WriteLine("\t\tcost: " + reader.ReadString());
                                    break;
                            }
                    }
                    Console.WriteLine("-------------------------------------------------");
                }
            }
            catch (Exception ex)
            {
                Dialogs.DisplayException(ex);
            }
        }
    }
}
