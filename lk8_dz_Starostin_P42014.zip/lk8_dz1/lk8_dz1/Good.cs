﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;

namespace lk8_dz1
{
    class Good:XMLEnable
    {
        private string name;
        private double cost;
        private string currency;
        private int amount;
        private List<Attribute> attr;
        class Attribute
        {
            public string name;
            public string val;
            public Attribute(string name, string val)
            {
                this.name = name;
                this.val = val;
            }
        }
        public void AddAttribute(string name, string val)
        {
            this.attr.Add(new Attribute(name, val));
        }
        public void SaveAsXmlNode(ref XmlTextWriter writer)
        {
            writer.WriteStartElement("good");
            if(attr.Count != 0)
            {
                for(int i = 0; i < attr.Count; ++i)
                {
                    writer.WriteAttributeString(attr[i].name, attr[i].val);
                }
            }
            writer.WriteElementString("name", name);
            writer.WriteElementString("cost", cost.ToString());
            writer.WriteElementString("currency", currency);
            writer.WriteElementString("amount", amount.ToString());
            writer.WriteEndElement();
        }
        public Good(string name, double cost, string currency="USD", int amount = 1)
        {
            this.attr = new List<Attribute>();
            this.name = name;
            this.cost = cost;
            this.currency = currency;
            this.amount = amount;
        }
    }
}
