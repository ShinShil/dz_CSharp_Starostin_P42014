﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

namespace lk8_dz1
{
    //DialogMakingOrders()  - function to create any number of orders
    class Program
    {
        static void Main(string[] args)
        {
            List<Order> orders = new List<Order>();
            Console.WriteLine("Use template(1 - default) or handle mode(2) (enter 1 or 2)");
            string answ = Console.ReadLine();
            if(answ.StartsWith("2"))
                orders = DialogMakingOrders();
            else
                orders.Add(TemplateOrder());

            string str = "order";
            string extension = ".xml";
            Dialogs.SetCounter(1);
            string fileName = str + Dialogs.ReadCounter() + extension;
            string basePath = "C:\\test\\" + fileName;

            XmlTextWriter writer = null;
            try
            {
                writer = new XmlTextWriter(basePath, System.Text.Encoding.Unicode);
                writer.Formatting = Formatting.Indented;
                writer.WriteStartDocument();
                for (int i = 0; i < orders.Count; ++i)
                {
                    orders[i].SaveAsXmlNode(ref writer);
                }

            }
            catch (Exception ex)
            {
                Dialogs.DisplayException(ex);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
            
            Console.WriteLine("XML saved to: " + basePath);
        }
        static Order TemplateOrder()
        {
            Good good1 = new Good("good1", 12);
            good1.AddAttribute("rare", "unique");
            Good good2 = new Good("good2", 14);
            good2.AddAttribute("rare", "common");
            Order order1 = new Order();
            order1.AddGood(good1);
            order1.AddGood(good2);
            return order1;
        }
        static List<Order> DialogMakingOrders()
        {
            List<Order> orders = new List<Order>();

            while (true)
            {
                Console.Clear();
                if (ifContinue("оформление заказа"))
                    orders.Add(AddOrder());
                else break;
            }
            return orders;
        }
        static bool ifContinue(string str)
        {
            Console.WriteLine("Вы желаете выполнить " + str + "? y(es)/n(o)");
            string answ = Console.ReadLine();
            if (answ.StartsWith("y"))
                return true;
            else return false;

        }

        static Order AddOrder()
        {
            Order res = new Order();
            Console.WriteLine("\n\tОформление заказа\n");
            while (true)
            {
                if (!ifContinue("добавление товара"))
                    break;
                res.AddGood(AddGood());
            }
            return res;
        }

        
        static Good AddGood()
        {
            Console.WriteLine("\n\tДобавление товара\n");
            string name = Dialogs.TakeStr("Имя: ");
            double cost = Dialogs.TakeDouble("Цена: ");
            string curr = Dialogs.TakeStr("Валюта: ");
            if (curr == "")
                curr = "USD";            
            int amount = Dialogs.TakeInt("Количество: ");
            Good res = new Good(name, cost, curr, amount);
            while (true)
            {
                if (!ifContinue("добавление аттрибута"))
                    break;
                AddAttribute(ref res);
            }
            return res;
        }

        static void AddAttribute(ref Good good)
        {
            Console.WriteLine("\n\tДобавление аттрибутов\n");
            Console.Write("Имя аттрибута: ");
            string attrName = Console.ReadLine();
            Console.Write("Значение аттрибута:");
            string attrVal = Console.ReadLine();
            good.AddAttribute(attrName, attrVal);
        }
    }
}
