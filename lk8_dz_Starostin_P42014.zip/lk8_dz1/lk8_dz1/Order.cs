﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.IO;
namespace lk8_dz1
{
    class Order:XMLEnable
    {
        private List<Good> goods;
        public Order()
        {
            this.goods = new List<Good>();
        }
        public bool AddGood(Good good)
        {
            goods.Add(good);
            return true;
        }

        public void SaveAsXmlNode(ref XmlTextWriter writer)
        {
            writer.WriteStartElement("order");
                if (goods.Count != 0)
                {
                    writer.WriteStartElement("goods");
                    for (int i = 0; i < goods.Count; ++i)
                    {
                        goods[i].SaveAsXmlNode(ref writer);
                    }
                    writer.WriteEndElement();
                }
            writer.WriteEndElement();
        }
    }
}
