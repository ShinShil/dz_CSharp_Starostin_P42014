﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
namespace lk8_dz1
{
    public interface XMLEnable
    {
        void SaveAsXmlNode(ref XmlTextWriter writer);
    }
    static class Dialogs
    {
        static public string TakeStr(string whatToTake)
        {
            Console.Write(whatToTake);
            return Console.ReadLine();
        }
        static public double TakeDouble(string whatToTake, int bottomVal = 0, int topVal = int.MaxValue, bool flag = true)
        {
            double res;
            Console.Write(whatToTake);
            string tmp = Console.ReadLine();
            while (!Double.TryParse(tmp, out res) || (res <= bottomVal  && flag) || (res >= topVal && flag))
            {
                Console.WriteLine("\nОбнаружен ошибочный ввод - " + tmp);
                Console.Write("\n" + whatToTake);
                tmp = Console.ReadLine();
            }
            return res;
        }
        static public int TakeInt(string whatToTake, int bottomVal = 0, int topVal = int.MaxValue, bool flag = true)
        {
            int res;
            Console.Write(whatToTake);
            string tmp = Console.ReadLine();
            while (!Int32.TryParse(tmp, out res) || (res <= bottomVal && flag) || (res >= topVal && flag))
            {
                if (tmp == "")
                {
                    res = 1;
                    break;
                }
                Console.WriteLine("\nОбнаружен ошибочный ввод - " + tmp);
                Console.Write("\n" + whatToTake);
                tmp = Console.ReadLine();
            }
            return res;
        }

        static public void SetCounter(int newVal = 0, string path = "C:\\test\\counter.bin")
        {
            try {
                using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
                {
                    BinaryWriter bw = new BinaryWriter(fs);
                    bw.Write(newVal);
                    bw.Flush();
                    bw.Close();
                }
            }
            catch(Exception ex)
            {
                DisplayException(ex);
            }
        }
        static public int ReadCounter(bool incr = true, string path = "C:\\test\\counter.bin")
        {
            int res;
            try
            {
                using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    BinaryReader br = new BinaryReader(fs);
                    res = br.ReadInt32();
                    br.Close();
                    if(incr)
                    {
                        SetCounter(res + 1);
                    }
                    return res;
                }
            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
            return -1;
        }
        static public void DisplayException(Exception ex)
        {
            Console.WriteLine("\nType Exception: " + ex.GetType());
            Console.WriteLine(ex.Message + "\n");
            Console.WriteLine(ex.StackTrace + "\n\n");
            Console.WriteLine("Source: " + ex.Source + "\n\n");
        }
    }
}
