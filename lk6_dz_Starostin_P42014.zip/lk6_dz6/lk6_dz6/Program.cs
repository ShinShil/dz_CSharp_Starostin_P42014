﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите строку состоящую из слов: ");
            string str = Console.ReadLine();

            string[] words = str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, int> wordsInStr = new Dictionary<string, int>();
            List<string> keys = new List<string>();
            int maxSz = 6;
            foreach(string w in words)
            {
                if(wordsInStr.ContainsKey(w))
                {
                    ++wordsInStr[w];
                }else
                {
                    if (w.Length > maxSz)
                        maxSz = w.Length;
                    keys.Add(w);
                    wordsInStr.Add(w, 1);
                }
            }

            Console.WriteLine("\nРезультат\n");
            Console.WriteLine("{0, -" + maxSz + "}: {1, 3}", "Слово", "Кол-во раз");

            foreach (string key in keys)
                Console.WriteLine("{0, -"+maxSz + "}: {1, 3}", key, wordsInStr[key]);
            Console.WriteLine("------------------------");
        }
    }
}
