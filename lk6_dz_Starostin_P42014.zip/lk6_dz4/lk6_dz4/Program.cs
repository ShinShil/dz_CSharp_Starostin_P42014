﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz4
{
    class Program
    {
        static void Main(string[] args)
        {
            Point3D p3 = new Point3D(1, 2, 3);
            Console.WriteLine(p3);
        }
    }
}
