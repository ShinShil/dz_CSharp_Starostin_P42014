﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz4
{
    class Point3D: Point2D<double>
    {
        double z;
        public Point3D():base() {
            z = default(double);
        }

        public double Z
        {
            get { return z; }
            set { z = value; }
        }
        public Point3D(double x, double y, double z):base(x,y)
        {
            this.z = z;
        }

        public override string ToString()
        {
            return String.Format("X = {0}, Y = {1}, Z = {2}", X, Y, z);
        }
    }
}
