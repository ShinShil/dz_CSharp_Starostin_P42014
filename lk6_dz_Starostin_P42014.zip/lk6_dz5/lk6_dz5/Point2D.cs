﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz5
{
    class Point2D<T>
    {
        T x;
        T y;
        public T X
        {
            get { return x; }
            set { x = value; }
        }
        public T Y
        {
            get { return y; }
            set { y = value; }
        }

        public Point2D(T x, T y)
        {
            this.x = x;
            this.y = y;
        }

        public Point2D()
        {
            this.x = default(T);
            this.y = default(T);
        }

        public override string ToString()
        {
            return String.Format("X = {0}, Y = {1}", x, y);
        }
    }
}
