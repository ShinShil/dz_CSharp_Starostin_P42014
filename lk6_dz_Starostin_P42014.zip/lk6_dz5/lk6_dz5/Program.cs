﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz5
{
    class Program
    {
        static void Main(string[] args)
        {
            Line<double> line = new Line<double>(1, 2, 3, 4);
            Line<int> line2 = new Line<int>(new Point2D<int>(5, 6), new Point2D<int>(7, 8));

            Console.WriteLine("Line 1\n{0}\n\nLine 2\n{1}", line, line2);
        }
    }
}
