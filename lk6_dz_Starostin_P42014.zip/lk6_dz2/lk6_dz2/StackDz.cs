﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz2
{
    class StackDz<T>
    {
        private class Node {
            public Node()
            {
                prev = null;
                val = default(T);
            }
            public T val;
            public Node prev;
        }
        Node top;
        private int maxSize;
        private int count;
        public int Count
        {
            get { return count; }
        }
        public int MaxSize
        {
            get { return maxSize; }
        }
        public StackDz()
        {
            maxSize = -1;
            top = default(Node);
            count = 0;
        }

        public StackDz(int maxSize)
            :this()
        {
            this.maxSize = maxSize;
        }

        public bool Push(T val)
        {
            if(maxSize == -1 || count<maxSize)
            {
                Node tmp = new Node();
                tmp.prev = top;
                tmp.val = val;
                top = tmp;
                ++count;
                return true;
            }
            else
            {
                return false;
            }

        }

        public T Pop()
        {
            T res = top.val;
            top = top.prev;
            --count;
            return res;
        }

        public T Peek()
        {
            return top.val;
        }

        public void Show()
        {
            if(top == null)
            {
                Console.WriteLine("Stack is empty");
                return;
            }
            Node tmp = top;
            while(tmp!=null)
            {
                Console.WriteLine(tmp.val);
                tmp = tmp.prev;
            }
        }
        public void Clear()
        {
            while(top!=null)
            {
                this.Pop();
            }
        }
    }
}
