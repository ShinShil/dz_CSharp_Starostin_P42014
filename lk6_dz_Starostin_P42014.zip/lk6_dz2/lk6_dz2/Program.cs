﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n\tGeneric stack example\n");
            StackDz<int> st = new StackDz<int>(4);
            st.Push(1);
            st.Push(2);
            st.Push(3);
            st.Push(4);
            st.Push(5);
            Console.WriteLine("Stack");
            st.Show();
            Console.WriteLine("Pop()");
            st.Pop();
            st.Show();
            object size;
            if (st.MaxSize == -1)
                size = "any size";
            else size = (st.MaxSize);
            Console.Write("Max size - {0}; Count - {1}; " , size, st.Count );
            Console.WriteLine("Clear()");
            st.Clear();
            st.Show();
            Console.Write("Max size - {0}; Count - {1}; ", size, st.Count);



        }
    }
}
