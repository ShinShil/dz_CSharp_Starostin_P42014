﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz3
{
    class Program
    {
        static void Main(string[] args)
        {
            DictionaryDz dict = new DictionaryDz();
            dict.Add("hello", "привет");
            dict.Add("medium", "средний");
            while (true)
            {

                Console.WriteLine("Текущее направление перевода: " + dict.StringDirection);
                Console.WriteLine("c - change, any key - continue");
                string answ = Console.ReadKey(true).KeyChar.ToString();
                if (answ.ToLower().StartsWith("c"))
                    dict.ChangeDirection();
                Console.Write("\nВведите слово для перевода: ");
                string word = Console.ReadLine();
                string res = dict.Translate(word);
                if (res != null)
                    Console.WriteLine("Результат перевода - {0}", res);
                else
                {
                    Console.WriteLine("Перевод не найден");
                }
                Console.WriteLine("Желаете продолжить? (Y/N)");
                answ = Console.ReadKey(true).KeyChar.ToString();
                if (answ.ToLower().StartsWith("n"))
                    break;
                else {
                    Console.WriteLine("---------------------");
                    continue;
                }
            }
        }
    }
}
