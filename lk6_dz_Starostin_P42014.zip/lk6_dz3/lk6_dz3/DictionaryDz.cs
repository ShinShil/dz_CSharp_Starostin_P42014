﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk6_dz3
{
    class DictionaryDz
    {
        public enum Directions
        {
            EnglRus = 0,
            RusEngl = 1
        }
        public string StringDirection
        {
            get {
                switch (Direction)
                {
                    case Directions.EnglRus:
                        return "English -> Русский";
                    case Directions.RusEngl:
                        return "Русский -> English";
                }
                return null;
            }
        }
        public void ChangeDirection()
        {
            if (direction == Directions.EnglRus)
                direction = Directions.RusEngl;
            else
                direction = Directions.EnglRus;
        }
        Directions direction;
        Dictionary<string, string> EnglRus = new Dictionary<string, string>();
        Dictionary<string, string> RusEngl = new Dictionary<string, string>();
        public void Add(string english, string russian)
        {
            english = english.ToLower();
            russian = russian.ToLower();
            direction = Directions.EnglRus;
            EnglRus.Add(english, russian);
            RusEngl.Add(russian, english);
        }
        public Directions Direction
        {
            get { return direction; }
            set { direction = value; }
        }
        public string Translate(string word)
        {
            word = word.ToLower();
            switch (direction)
            {
                case Directions.EnglRus:
                    if (EnglRus.ContainsKey(word))
                        return EnglRus[word];
                    break;
                case Directions.RusEngl:
                    if (RusEngl.ContainsKey(word))
                        return RusEngl[word];
                    break;
            }
            return null;
        }

    }
}
