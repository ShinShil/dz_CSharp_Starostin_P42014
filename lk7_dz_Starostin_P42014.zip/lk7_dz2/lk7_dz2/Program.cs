﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace lk7_dz2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter the path: ");
            string path = Console.ReadLine();
            try
            {
                using(StreamReader reader = new StreamReader(path))
                {
                    FileInfo f = new FileInfo(path);
                    
                    Console.WriteLine("Would you like to save result in the res.txt? y(es) / n(o)");
                    string answ = Console.ReadLine();
                    if (answ.ToLower().StartsWith("y")) {
                        Regex reg = new Regex(f.Name, RegexOptions.Compiled | RegexOptions.ExplicitCapture);
                        string newPath, oldPath;
                        oldPath = f.FullName;
                        newPath = reg.Replace(oldPath, "res.txt");
                        Console.WriteLine(oldPath + "   " + f.Name);
                        Console.WriteLine(newPath);

                        string xml = reader.ReadToEnd();
                        string pattern = "<.+?>";
                        string repl = " ";
                        Regex regXml = new Regex(pattern, RegexOptions.Multiline | RegexOptions.ExplicitCapture | RegexOptions.Compiled);
                        string resXml = regXml.Replace(xml, repl);
                        Console.WriteLine("\n\n" + resXml);
                        using (FileStream file = new FileStream(newPath, FileMode.Create, FileAccess.Write, FileShare.Write))
                        {
                            StreamWriter ws = new StreamWriter(file);
                            ws.Write(resXml);
                            ws.Dispose();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception " + ex.GetType());
                Console.WriteLine(ex.Message);
            }
        }
    }
}
