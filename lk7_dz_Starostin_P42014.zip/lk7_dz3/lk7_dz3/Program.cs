﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace lk7_dz3
{
    class Program
    {
        static void Main(string[] args)
        {
           
            /*
            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.Title = "Horse";
            Console.WindowWidth = 80;
            */
            try {
                ApplicationSettingsHelper.Load("C:\\test\\console.bin");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
