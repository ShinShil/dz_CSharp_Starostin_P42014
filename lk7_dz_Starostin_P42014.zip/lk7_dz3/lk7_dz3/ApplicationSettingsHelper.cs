﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lk7_dz3
{
    static class ApplicationSettingsHelper
    {
        static public void Load(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                BinaryReader br = new BinaryReader(fs);
                Console.Title = br.ReadString();
                int tmp = br.ReadInt32();
                Console.BackgroundColor = (ConsoleColor)tmp;
                Console.WindowWidth = br.ReadInt32();
                
            }

        }
        static public void Save(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Write))
            {
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(Console.Title);
                bw.Write((int)Console.BackgroundColor);
                bw.Write(Console.WindowWidth);
                bw.Flush();
            }
        }
    }
}
