﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lk7_dz1
{
    class EditFolderMenu:Menu
    {
        private DirectoryInfo dir;

        public EditFolderMenu(DirectoryInfo dir)
        {
            this.dir = dir;
            this.AddRecord("1.Move", Move);
            this.AddRecord("2.Delete", Delete);
            this.AddRecord("3.Exit", EndDlg);
        }

        private void Delete()
        {
            Console.Clear();
            Console.WriteLine("\n\tDeleting directory: {0}", dir.FullName);
            string s = dir.FullName;
            try
            {
                dir.Delete();
                Console.WriteLine("\nThe next dir was deleted:{0}\nPress any key to continue...", s);
                Console.ReadKey();
                EndDlg();
            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
        }
        private void Move()
        {
            Console.Clear();
            Console.WriteLine("\n\tMoving dir: {0}", dir.FullName);
            Console.Write("Enter target path: ");
            string newPath = Console.ReadLine();
            try
            {
                dir.MoveTo(newPath);
                Console.WriteLine("\nFile succesfully moved to:{0}\nPress any key to continue...", newPath);
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
        }

        public override void Show()
        {
            Console.Clear();
            Console.WriteLine("\n\tOperations with dir: {0}\n", dir.FullName);

            for (int i = 0; i < recs.Count; ++i)
            {
                if (i == recs.Count - 1)
                    Console.WriteLine("--------");
                Console.WriteLine(recs[i]._case);
            }
        }
    }
}

