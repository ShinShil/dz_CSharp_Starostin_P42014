﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lk7_dz1
{
    public delegate bool EqualFiles(FileInfo file, string val);
    public delegate bool EqualFolders(DirectoryInfo dir, string val);
    class Files
    {
        private FileMenu mainMenu;
        private FileMenu SearchFileMenu;
        private FileMenu FolderFileMenu;

        public event ChangeStr pathChanged;
       
        private string currFolderPath;
        public Files()
        {
            currFolderPath = "C:\\test";
            mainMenu = new FileMenu(currFolderPath);
            SearchFileMenu = new FileMenu(currFolderPath);
            FolderFileMenu = new FileMenu(currFolderPath);
            pathChanged += new ChangeStr(mainMenu.ChangePath);
            pathChanged += new ChangeStr(SearchFileMenu.ChangePath);
            pathChanged += new ChangeStr(FolderFileMenu.ChangePath);

            mainMenu.SetHeader("\n\tMain menu\n");
            mainMenu.AddRecord("1.Search files", new MenuAction(SearchFiles));
            mainMenu.AddRecord("2.Search folders", new MenuAction(SearchFolders));
            mainMenu.AddRecord("3.Search files by content", new MenuAction(SearchByContent));
            mainMenu.AddRecord("4.Create a file", new MenuAction(CreateFile));
            mainMenu.AddRecord("5.Create a folder", new MenuAction(CreateFolder));
            mainMenu.AddRecord("6.Set new current path", new MenuAction(SetNewCurrFolderPath));
            mainMenu.AddRecord("7.Exit", new MenuAction(mainMenu.EndDlg));

            SearchFileMenu.SetHeader("\n\tSearch file menu\n");
            SearchFileMenu.AddRecord("1.Search by name", new MenuAction(SearchByName));
            SearchFileMenu.AddRecord("2.Search by date", new MenuAction(SearchByDateCreate));
            SearchFileMenu.AddRecord("3.Search by size", new MenuAction(SearchBySize));
            SearchFileMenu.AddRecord("4.Search by access", new MenuAction(SearchByDateAccess));
            SearchFileMenu.AddRecord("5.Search by last change", new MenuAction(SearchByDateWrite));
            SearchFileMenu.AddRecord("6.Exit", new MenuAction(SearchFileMenu.EndDlg));

            FolderFileMenu.SetHeader("\n\tSearch folder menu\n");
            FolderFileMenu.AddRecord("1.Search by name", new MenuAction(SearchByNameFolder));
            FolderFileMenu.AddRecord("2.Search by date", new MenuAction(SearchByDateCreateFolder));
            FolderFileMenu.AddRecord("3.Search by access", new MenuAction(SearchByDateAccessFolder));
            FolderFileMenu.AddRecord("4.Search by last change", new MenuAction(SearchByDateWriteFolder));
            FolderFileMenu.AddRecord("5.Exit", new MenuAction(FolderFileMenu.EndDlg));
        }
        private void SetNewCurrFolderPath()
        {
            Console.WriteLine("Введите новый путь: ");
            currFolderPath = Console.ReadLine();
            pathChanged(this, currFolderPath);
        }
        public void Dlg()
        {
            mainMenu.StartDlg();
        }

        #region SearchFiles
        private void SearchFilesByAttributes(EqualFiles cmpFiles, string consoleMessage = "")
        {
            DirectoryInfo dir = new DirectoryInfo(currFolderPath);
            List<FileInfo> files = new List<FileInfo>();
            Console.Write(consoleMessage);
            string valForFind = Console.ReadLine();
            RecSearchFiles(dir, ref files, cmpFiles, valForFind);
          
                /* Menu tempMenu = new Menu();
                 tempMenu.SetHeader("\nResult of search:\n");
                 for (int i = 0; i < files.Count; ++i)
                     tempMenu.AddRecord(String.Format("{0}. {1}", i + 1, files[i].FullName), new MenuAction(delegate()
                     {
                         EditFileMenu EditMenu = new EditFileMenu(files[i]);
                         EditMenu.StartDlg();
                     }));
                 tempMenu.AddRecord(String.Format("{0}. Exit", files.Count + 1), new MenuAction(delegate()
                 {
                     tempMenu.EndDlg();
                 }));
                 tempMenu.StartDlg();*/
            while (!ProcessSearchResult(files));                          
        }

        public bool ProcessSearchResult(List<FileInfo> files)
        {
            Console.Clear();
            if (files.Count == 0)
            {
                Console.Write("\nResult of search:\n\n");
                Console.WriteLine("No such files");
                Console.WriteLine("\nPress any key. . .");
                Console.ReadKey();
                return true;
            }
            else {
                Console.Write("\nResult of search:\n\n");
                for (int i = 0; i < files.Count; ++i)
                    Console.WriteLine("{0}. {1}", i + 1, files[i].FullName);
                Console.WriteLine("{0}. Exit", files.Count + 1);
                int choice;
                Console.Write("\nMake a choice: ");
                string s = Console.ReadLine();
                while (!Int32.TryParse(s, out choice) || (choice < 0 || choice > files.Count + 1))
                {
                    Console.Clear();
                    Console.Write("\nResult of search:\n\n");
                    for (int i = 0; i < files.Count; ++i)
                        Console.WriteLine("{0}. {1}", i + 1, files[i].FullName);
                    Console.WriteLine("{0}. Exit", files.Count + 1);
                    Console.WriteLine("\nError, incorrect input: " + s);
                    Console.Write("\nMake a choice: ");
                    s = Console.ReadLine();
                }
                if (choice == files.Count + 1)
                {
                    return true;
                }
                else
                {
                    EditFileMenu EditMenu = new EditFileMenu(files[choice - 1]);
                    EditMenu.StartDlg();
                }
                return false;
            }
        }

        private void RecSearchFiles(DirectoryInfo dir, ref List<FileInfo> files, EqualFiles equal, string val)
        {
            DirectoryInfo[] subdir = dir.GetDirectories();
            for (int i = 0; i < subdir.Length; ++i)
            {
                RecSearchFiles(subdir[i], ref files, equal, val);
            }
            FileInfo[] tempFiles = dir.GetFiles();
            for (int i = 0; i < tempFiles.Length; ++i)
            {
                if (equal(tempFiles[i], val))
                    files.Add(tempFiles[i]);
            }
            if (subdir.Length == 0)
                return;
        }
        private void SearchFiles()
        {
            SearchFileMenu.StartDlg();
        }

        #region EntryPointsFindAttributes
        private void SearchByName()
        {
            SearchFilesByAttributes(new EqualFiles(EqualFilesNames), "Введите часть или имя файла:");
        }
        private void SearchByDateCreate()
        {
            SearchFilesByAttributes(new EqualFiles(EqualFilesDateCreation), "Введите часть или целиком дату создания файла:");
        }
        private void SearchByDateAccess()
        {
            SearchFilesByAttributes(new EqualFiles(EqualFilesDateAcces), "Введите часть или целиком дату последнего доступа к файлу:");
        }
        private void SearchByDateWrite()
        {
            SearchFilesByAttributes(new EqualFiles(EqualFilesWriteTime), "Введите часть или целиком дату последнего измения файла:");
        }
        private void SearchBySize()
        {
            SearchFilesByAttributes(new EqualFiles(EqualFilesSizes), "Введите размер файла:");
        }
        #endregion

        #region EqualFilesDelegates
        private bool EqualFilesNames(FileInfo f, string name)
        {
            if (f.FullName.IndexOf(name) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFilesDateCreation(FileInfo f, string date)
        {
            if (f.CreationTime.ToString().IndexOf(date) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFilesDateAcces(FileInfo f, string date)
        {
            if (f.LastAccessTime.ToString().IndexOf(date) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFilesSizes(FileInfo f, string size)
        {
            long tmp;
            if (!Int64.TryParse(size, out tmp))
                return false;
            if (f.Length == tmp)
                return true;
            else
                return false;
        }
        private bool EqualFilesWriteTime(FileInfo f, string date)
        {
            if (f.LastWriteTime.ToString().IndexOf(date)!=-1)
                return true;
            else
                return false;
        }
        #endregion
        #endregion

        #region SearchFolders
        private void SearchFolders()
        {
            FolderFileMenu.StartDlg();
        }
        public bool ProcessSearchResultFolder(List<DirectoryInfo> files)
        {
            Console.Clear();
            if (files.Count == 0)
            {
                Console.Write("\nResult of search:\n\n");
                Console.WriteLine("No such directories");
                Console.WriteLine("\nPress any key. . .");
                Console.ReadKey();
                return true;
            }
            else {
                Console.Write("\nResult of search:\n\n");
                for (int i = 0; i < files.Count; ++i)
                    Console.WriteLine("{0}. {1}", i + 1, files[i].FullName);
                Console.WriteLine("{0}. Exit", files.Count + 1);
                int choice;
                Console.Write("\nMake a choice: ");
                string s = Console.ReadLine();
                while (!Int32.TryParse(s, out choice) || (choice < 0 || choice > files.Count + 1))
                {
                    Console.Clear();
                    Console.Write("\nResult of search:\n\n");
                    for (int i = 0; i < files.Count; ++i)
                        Console.WriteLine("{0}. {1}", i + 1, files[i].FullName);
                    Console.WriteLine("{0}. Exit", files.Count + 1);
                    Console.WriteLine("\nError, incorrect input: " + s);
                    Console.Write("\nMake a choice: ");
                    s = Console.ReadLine();
                }
                if (choice == files.Count + 1)
                {
                    return true;
                }
                else
                {
                    EditFolderMenu EditMenu = new EditFolderMenu(files[choice - 1]);
                    EditMenu.StartDlg();
                }
                return false;
            }
        }

        private void SearchFoldersByAttributes(EqualFolders cmpDirs, string consoleMessage = "")
        {
            DirectoryInfo dir = new DirectoryInfo(currFolderPath);
            List<DirectoryInfo> dirs = new List<DirectoryInfo>();
            Console.Write(consoleMessage);
            string valForFind = Console.ReadLine();
            RecSearchFolders(dir, ref dirs, cmpDirs, valForFind);
            while(!ProcessSearchResultFolder(dirs));

        }
        private void RecSearchFolders(DirectoryInfo dir, ref List<DirectoryInfo> dirs, EqualFolders equal, string val)
        {
            DirectoryInfo[] subdir = dir.GetDirectories();
            if (subdir.Length == 0)
                return;
            for (int i = 0; i < subdir.Length; ++i)
            {
                if (equal(subdir[i], val))
                    dirs.Add(subdir[i]);
                RecSearchFolders(subdir[i], ref dirs, equal, val);
            }
        }

        #region EntryPointsFindAttributesFolders
        private void SearchByNameFolder()
        {
            SearchFoldersByAttributes(new EqualFolders(EqualFoldersNames), "\nEnter the part or full name of the file:");
        }
        private void SearchByDateCreateFolder()
        {
            SearchFoldersByAttributes(new EqualFolders(EqualFoldersDateCreation), "Введите часть или целиком дату создания файла:");
        }
        private void SearchByDateAccessFolder()
        {
            SearchFoldersByAttributes(new EqualFolders(EqualFoldersDateAcces), "Введите часть или целиком дату последнего доступа к файлу:");
        }
        private void SearchByDateWriteFolder()
        {
            SearchFoldersByAttributes(new EqualFolders(EqualFoldersWriteTime), "Введите часть или целиком дату последнего измения файла:");
        }
       
        #endregion

        #region EqualFoldersDelegates
        private bool EqualFoldersNames(DirectoryInfo d, string name)
        {
            if (d.FullName.IndexOf(name) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFoldersDateCreation(DirectoryInfo d, string date)
        {
            if (d.CreationTime.ToString().IndexOf(date) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFoldersDateAcces(DirectoryInfo d, string date)
        {
            if (d.LastAccessTime.ToString().IndexOf(date) != -1)
                return true;
            else
                return false;
        }
        private bool EqualFoldersWriteTime(DirectoryInfo d, string date)
        {
            if (d.LastWriteTime.ToString().IndexOf(date) != -1)
                return true;
            else
                return false;
        }
        #endregion

        #endregion

      
        private void CreateFile()
        {
            Console.Clear();
            Console.WriteLine("\n\tCreating a new file at: " + currFolderPath + "\n");
            Console.WriteLine("Enter the name for file: ");
            string s = Console.ReadLine();
            try {
                File.Create(String.Format(currFolderPath + "\\" + s));
                Console.WriteLine("File succefully created");
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }
            catch(Exception ex)
            {
                Menu.DisplayException(ex);
            }
        }

        private void CreateFolder()
        {
            Console.Clear();
            Console.WriteLine("\n\tCreating a new folder at: " + currFolderPath + "\n");
            Console.WriteLine("Enter the name for folder: ");
            string s = Console.ReadLine();
            try {
                Directory.CreateDirectory(String.Format(currFolderPath + "\\" + s));
                Console.WriteLine("Folder succefully created");
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
            }
            catch(Exception ex)
            {
                Menu.DisplayException(ex);
            }
        }
        private void SearchByContent()
        {
            Console.WriteLine("Enter the string for search in .txt files: ");
            string searchStr = Console.ReadLine();
            List<FileInfo> txtFiles = new List<FileInfo>();
            DirectoryInfo dir = new DirectoryInfo(currFolderPath);
            RecSearchFiles(dir, ref txtFiles, new EqualFiles(EqualFilesNames), ".txt");
            Console.WriteLine("\n\tThe result of search\n");
            if (txtFiles.Count == 0)
            {
                Console.WriteLine("No such entries\n");
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                return;
            }
            else
            {
                List<FileInfo> suitFiles = new List<FileInfo>();
                List<String> strReplace = new List<String>();
                for(int i = 0; i<txtFiles.Count; ++i)
                {
                    using (FileStream fs = new FileStream(txtFiles[i].FullName, FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        fs.Seek(0, SeekOrigin.Begin);
                        Byte[] readBytes = new byte[(int)fs.Length];
                        fs.Read(readBytes, 0, readBytes.Length);
                        string text = Encoding.UTF8.GetString(readBytes);
                        if (text.IndexOf(searchStr) != -1)
                        {
                            suitFiles.Add(txtFiles[i]);
                            strReplace.Add(text);
                        }
                    }
                }
                if(suitFiles.Count == 0)
                {
                    Console.WriteLine("No such entries\n");
                    Console.WriteLine("Press any key to continue");
                    Console.ReadKey();
                    return;
                }
                else
                {
                    string header = "\n\tSearch result\n";
                    for(int  i = 0; i<suitFiles.Count; ++i)
                    {
                        header += String.Format("{0}\n", suitFiles[i].FullName);
                        
                    }
                    
                    Menu tmpMenu = new Menu();
                    tmpMenu.SetHeader(header);
                    tmpMenu.AddRecord("1.Replace str in files", delegate ()
                    {
                        Console.WriteLine("Enter the new str: ");
                        string newStr = Console.ReadLine();
                        for(int i = 0; i<strReplace.Count; ++i)
                        {
                        using (StreamWriter file = new StreamWriter(suitFiles[i].FullName))
                            {
                                strReplace[i] = strReplace[i].Replace(searchStr, newStr);
                                file.Write(strReplace[i]);
                            }
                        }
                        Console.WriteLine("\nOperation finished");
                        tmpMenu.EndDlg();
                    });
                    tmpMenu.AddRecord("2.Exit", tmpMenu.EndDlg);
                    tmpMenu.StartDlg();

                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                }
            }
        }
    }
}
