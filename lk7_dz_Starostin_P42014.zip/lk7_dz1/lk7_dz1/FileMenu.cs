﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lk7_dz1
{
    class FileMenu: Menu
    {
        private string path;
        public FileMenu(string path) : base() { this.path = path; }

        public override void Show()
        {
            if (Header != "")
                Console.WriteLine(Header);
            for (int i = 0; i < recs.Count; ++i)
            {
                Console.WriteLine(recs[i]._case);
            }
            Console.WriteLine("Current path: {0}", path);
        }
        public void ChangePath(object sender, string str)
        {
            path = str;
        }

    }
}
