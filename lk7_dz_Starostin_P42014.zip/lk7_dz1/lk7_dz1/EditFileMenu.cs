﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Permissions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Xml;

namespace lk7_dz1
{
    class EditFileMenu:Menu
    {
        private FileInfo file;

        public EditFileMenu(FileInfo file)
        {
            this.file = file;
            this.AddRecord("1.Copy", Copy);
            this.AddRecord("2.Move", Move);
            this.AddRecord("3.Delete", Delete);
            this.AddRecord("4.Exit", EndDlg);
        }
      
        private void Delete()
        {
            Console.Clear();
            Console.WriteLine("\n\tDeleting file: {0}", file.FullName);
            string s = file.FullName;
            try
            {
                file.Delete();
                Console.WriteLine("\nThe next file was deleted:{0}\nPress any key to continue...", s);
                Console.ReadKey();
                EndDlg();
            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
        }
        private void Move()
        {
            Console.Clear();
            Console.WriteLine("\n\tMoving file: {0}", file.FullName);
            Console.Write("Enter target path: ");
            string newPath = Console.ReadLine();
            try {
                file.MoveTo(newPath);
                Console.WriteLine("\nFile succesfully moved to:{0}\nPress any key to continue...", newPath);
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
        }

        private void Copy()
        {
            Console.Clear();
            Console.Write("\n\tCoping file: {0}", file.FullName);
            Console.Write("Enter target path: ");
            string newPath = Console.ReadLine();
            try
            {
                file.CopyTo(newPath);
                Console.Write("\nFile succesfully copied to:{0}\nPress any key to continue...", newPath);
                Console.ReadKey();

            }
            catch (Exception ex)
            {
                DisplayException(ex);
            }
        }
        public override void Show()
        {
            Console.Clear();
            Console.WriteLine("\n\tOperations with file: {0}\n", file.FullName);

            for (int i = 0; i < recs.Count; ++i)
            {
                if (i == recs.Count - 1)
                    Console.WriteLine("--------");
                Console.WriteLine(recs[i]._case);
            }
        }
    }
}
