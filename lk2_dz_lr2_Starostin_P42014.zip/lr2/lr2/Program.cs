﻿/*
Comment v traslite:
    Funcii, kotorie realizuyut neposredstevenno Laboratornuyu Rabotu 2, v samom nizu: task1(), task2(), Main()
Comment:
    Functions, that are related to the Laboratory Task 2, are at the down of the list: task1(), task2(), Main()
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lr2
{
    class Program
    {
        static void Pause()
        {
            Console.WriteLine("Нажмите любую клавишу");
            Console.ReadKey();
        }
        static void PrintArr(string[] words)
        {
            for(int i = 0; i<words.Length;++i)
            {
                Console.WriteLine("   [{0}]: {1}", i, words[i]);
            }
        }
       

        static decimal MediumArithmetic(int[] arr)
        {
            if (arr.Length == 0)
                return -1;
            int nSumm = 0;
            for(int i = 0; i<arr.Length; ++i)
            {
                nSumm += arr[i];
            }
            return nSumm / arr.Length;
        }

        static void PrintArr2d(int[][] arr)
        {
            for(int i = 0; i<arr.Length; ++i)
            {
                Console.Write("[{0}]: ", i + 1);
                for(int j = 0; j<arr[i].Length; ++j)
                {
                    Console.Write("{0, 3} ",arr[i][j]);
                }
                Console.WriteLine();
            }
        }

        static void PrintArr(int[] arr)
        {
            for(int i = 0; i<arr.Length; ++i)
            {
                Console.Write(arr[i] + " ");
            }
        }

       

        static void SetArr(out int[][] arr)
        {
            Console.Clear();
            uint nRows, nCols;
            Console.Write("Введите кол-во массивов: ");

            while (!UInt32.TryParse(Console.ReadLine(), out nRows))
            {
                Console.WriteLine("\n!!!ОШИБКА!!! Неверный ввод");
                Console.Write("\nВведите кол-во массивов: ");
            }

            arr = new int[nRows][];

            for (int i = 0; i < nRows; ++i)
            {
                Console.Write("Введите кол-во элементов в массиве №{0}: ", i + 1);
                while (!UInt32.TryParse(Console.ReadLine(), out nCols))
                {
                    Console.WriteLine("\n!!!ОШИБКА!!! Неверный ввод");
                    Console.Write("Введите кол-во элементов в массиве №{0}: ", i + 1);
                }

                arr[i] = new int[nCols];
                Console.WriteLine("\nЭлементы массива [{0}]: ", i + 1);
                for(int j = 0; j<nCols; ++j)
                {
                    Console.Write("\t[{0}]: ", j + 1);
                    while(!Int32.TryParse(Console.ReadLine(), out arr[i][j]))
                    {
                        Console.WriteLine("\n!!!ОШИБКА!!! Неверный ввод");
                        Console.Write("\t[{0}]: ", j + 1);
                    }
                }
            }
        }

        static void GenerateArr(out int[][] arr)
        {
            int nRows, nCols;
            Random Rnd = new Random();
            nRows = Rnd.Next(1, 5);
            arr = new int[nRows][];
            for(int i = 0; i< nRows; ++i)
            {
                nCols = Rnd.Next(1, 10);
                arr[i] = new int[nCols];
                for(int j = 0; j< nCols; ++j)
                {
                    arr[i][j] = Rnd.Next(-55, 55);
                }
            }
        }

        static void task1()
        {
            string str;
            do
            {
                Console.Clear();
                Console.WriteLine("Введите не пустую строку: ");
                str = Console.ReadLine();
                Console.WriteLine();
            } while (str.Length == 0);

            char[] DelemiterChars = { ' ', '\t' };
            string[] words = str.Split(DelemiterChars, StringSplitOptions.RemoveEmptyEntries);
            int[] wordLength = new int[words.Length];
            uint nWordAmount = (uint)words.Length, nTAmount = 0;
            Console.WriteLine("Исходный порядок слов с строке: ");
            PrintArr(words);
            for (int i = 0; i < wordLength.Length; ++i)
            {
                wordLength[i] = words[i].Length;
                if (words[i][0] == 't')
                    ++nTAmount;
            }
            Array.Sort(wordLength, words);

            Console.WriteLine("\nВывод слов по возрастанию их длин: ");
            PrintArr(words);

            Console.WriteLine("\nКоличество слов в строке: " + nWordAmount);
            Console.WriteLine("Количество слов в строке, начинающихся на t: " + nTAmount + "\n");

            Pause();
        }

        static void task2(int[][] arr)
        {
            Console.Clear();

            if(arr.Length == 0)
            {
                Console.WriteLine("!!!Ошибка!!!Пустой массив\n");
                Pause();
                return;
            }

            Console.WriteLine("Исходный рваный массив: ");
            PrintArr2d(arr);
            Console.WriteLine();
            decimal[] nKeys = new decimal[arr.Length];
            for (int i = 0; i < nKeys.Length; ++i)
            {
                nKeys[i] = MediumArithmetic(arr[i]);
            }
            Array.Sort(nKeys, arr);
            int nMaxAmount = 1;
            decimal dMaxMediumArithmetic = MediumArithmetic(arr[arr.Length - 1]);
            for (int i = arr.Length - 2; i >= 0; --i)
            {
                if (MediumArithmetic(arr[i]) == dMaxMediumArithmetic)
                    ++nMaxAmount;
                else
                    break;
            }
            Console.WriteLine("Столбцы с максимальным средним арифметическим: ");
            for (int i = arr.Length - 1, j = 0; j < nMaxAmount; ++j, --i)
            {
                PrintArr(arr[i]);
                Console.WriteLine();
            }
            Console.WriteLine();
            Pause();
        }

        static void Main(string[] args)
        {
            int[][] arr = new int[3][];
            arr[0] = new int[] { 1, 2, 3, 4, 5, 6 };
            arr[1] = new int[] { 1, 2, 3 };
            arr[2] = new int[] { 1, 2, 3, 4, 5, 6 };
            int choice;
            for (;;)
            {
                Console.Clear();
                Console.WriteLine("\t\tЛабораторное задание 2\n\t\t\tВариант 11\n");
                Console.WriteLine("Текущий массив для задания 2: ");
                PrintArr2d(arr);
                Console.WriteLine();
                Console.WriteLine("1.Задание 1");
                Console.WriteLine("2.Задание 2");
                Console.WriteLine("3.Задать массив для задания 2 вручную");
                Console.WriteLine("4.Задать массив для задания 2 по умолчанию");
                Console.WriteLine("5.Сгенерировать случайный массив для задания 2");
                Console.WriteLine("6.Выход");
                Console.Write("\nВведите номер: ");
                while(!Int32.TryParse(Console.ReadLine(),out choice))
                {
                    Console.WriteLine("\n!!!ОШИБКА!!! Неверный ввод");
                    Console.Write("\nВведите номер: ");
                }
                switch(choice)
                {
                    case 1:task1(); break;
                    case 2:task2(arr); break;
                    case 3:SetArr(out arr); break;
                    case 4:
                        arr = new int[3][];
                        arr[0] = new int[] { 1, 2, 3, 4, 5, 6 };
                        arr[1] = new int[] { 1, 2, 3 };
                        arr[2] = new int[] { 1, 2, 3, 4, 5, 6 };
                        break;
                    case 5: GenerateArr(out arr); break;
                    case 6: Console.WriteLine(); return;
                }
            }
        }
    }
}

/*
Comment v traslite:
    Funcii, kotorie realizuyut neposredstevenno Laboratornuyu Rabotu 2, v samom nizu: task1(), task2(), Main()
Comment:
    Functions, that are related to the Laboratory Task 2, are at the down of the list: task1(), task2(), Main()
*/
